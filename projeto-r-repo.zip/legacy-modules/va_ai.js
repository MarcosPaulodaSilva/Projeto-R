
/* =====================================================================
   0.14.4 — PERCEPÇÃO DOS INIMIGOS + RIPOSTA
   Inimigos corpo a corpo da estrada deixam de ser onisciscientes:
   visão (cone + linha de visão), audição (ruído do jogador), última posição
   conhecida, INVESTIGATE -> SEARCH -> RETURN. Aparada perfeita abre RIPOSTA.
   ===================================================================== */
const AI_FOV_COS=Math.cos(75*Math.PI/180);          // cone de 150°
function aiLOS(x0,y0,x1,y1){
  const d=Math.hypot(x1-x0,y1-y0),n=Math.max(1,Math.ceil(d/.3));
  for(let i=1;i<n;i++){const t=i/n,x=Math.floor(lerp(x0,x1,t)),y=Math.floor(lerp(y0,y1,t));
    if(x<0||y<0||x>=N||y>=N)return false;const k=y*N+x;if(solid[k]&&ground[k]!==2)return false}
  return true;
}
function aiSees(e,t){
  const dx=t.x-e.x,dy=t.y-e.y,d=Math.hypot(dx,dy)||1,R=(e.d.aggro||6)*.75;
  if(d>R)return false;
  if(!aiLOS(e.x,e.y,t.x,t.y))return false;
  if(d<2.2||(e.alert||0)>0||e.state==='CHASE'||e.state==='ATTACK'||e.state==='RECOVER')return true; // percepção periférica / já em combate
  const fx=e.fx||-1,fy=e.fy||0,fl=Math.hypot(fx,fy)||1;
  return (fx*dx+fy*dy)/(fl*d)>=AI_FOV_COS;
}
function aiNoise(t){ // raio de audição gerado pela ação do jogador
  if(t!==P)return 0;
  let r=0;
  if(P.atk>0)r=7;else if(P.dodge>0)r=5;else if(P.block&&P.blockT<.4)r=4;
  else if(Math.hypot(P.vx||0,P.vy||0)>3)r=3.2;
  return r;
}
function aiHears(e,t){
  const r=aiNoise(t);if(!r)return false;
  const d=Math.hypot(t.x-e.x,t.y-e.y);
  return d<=r*(aiLOS(e.x,e.y,t.x,t.y)?1:.6);
}
function aiHouse(e,dt){ // manutenção comum dos estados próprios
  e.flash-=dt;e.cd-=dt;e.alert=Math.max(0,(e.alert||0)-dt);
  dangerMove(e,e.kx*dt,e.ky*dt);const kd=Math.exp(-dt*10);e.kx*=kd;e.ky*=kd;
}
function aiMark(e,ch){floatText(e.x,e.y-.4,ch,'xp')}
function aiToInvestigate(e,pos,why){
  e.state='INVESTIGATE';e.lastKnown=[pos[0],pos[1]];e.invT=7;e.phase=0;e.hit=false;e.aggroTarget=null;aiMark(e,'?');
  if(window.AI_LOG)window.AI_LOG.push({id:e.id||0,ev:'INVESTIGATE',why});
}
function aiToChase(e,target){e.state='CHASE';e.alert=.85;e.aggroTarget=target===NPC?'companion':'player';e.lostT=0;e.lastKnown=[target.x,target.y];aiMark(e,'!');sfx('pick')}
function aiEligible(e){return !(DG||e.dg||e.nightThreat||e.boss||e.ranged||e.elite||e.state==='DEAD')}
const aiBase=updEnemy;
updEnemy=function(e,dt){
  if(e.riposte>0)e.riposte-=dt;
  if(!aiEligible(e))return aiBase(e,dt);
  if(typeof MERGE_DEV!=='undefined'&&MERGE_DEV.aiPaused)return aiBase(e,dt);
  const D=e.d,hx=(e.sx??e.x),hy=(e.sy??e.y),target=enemyTarget(e),inZone=inDangerZone(e.x,e.y);
  e.lookT=(e.lookT||0)+dt;
  const seen=!!target&&inDangerZone(target.x,target.y)&&aiSees(e,target);
  const heard=!!target&&inDangerZone(target.x,target.y)&&aiHears(e,target);
  e.sees=seen;e.hears=heard;
  switch(e.state){
    case 'IDLE':{
      if(!inZone)return aiBase(e,dt);
      if(e.fx===undefined||e.fy===undefined){e.fx=-1;e.fy=0}
      if(seen){return aiBase(e,dt)} // base decide CHASE se estiver dentro do raio de aggro
      // varredura lenta de olhar
      const a=Math.atan2(e.homeFy??(e.homeFy=e.fy),e.homeFx??(e.homeFx=e.fx))+Math.sin(e.lookT*.7+(e.x*3.1))*.9;
      e.fx=lerp(e.fx,Math.cos(a),.05);e.fy=lerp(e.fy,Math.sin(a),.05);
      aiHouse(e,dt);e.vx=e.vy=0;
      if(heard)aiToInvestigate(e,[target.x,target.y],'ruido');
      return}
    case 'RETURN':{
      if(seen)return aiBase(e,dt); // base pode reengajar
      aiHouse(e,dt);e.hit=false;e.phase=0;
      if(heard){aiToInvestigate(e,[target.x,target.y],'ruido');return}
      const rx=hx-e.x,ry=hy-e.y,rd=Math.hypot(rx,ry);
      if(rd<.18){e.x=hx;e.y=hy;e.kx=e.ky=0;e.state='IDLE';return}
      e.fx=rx/rd;e.fy=ry/rd;steerMove(e,hx,hy,D.spd*.85,dt,true);return}
    case 'INVESTIGATE':{
      aiHouse(e,dt);e.invT-=dt;
      if(seen&&target){aiToChase(e,target);return}
      if(heard&&target)e.lastKnown=[target.x,target.y];
      const lk=e.lastKnown||[hx,hy],lx=lk[0]-e.x,ly=lk[1]-e.y,ld=Math.hypot(lx,ly);
      if(ld<.6||e.invT<=0){e.state='SEARCH';e.t=2.8;e.searchA=Math.atan2(e.fy||0,e.fx||-1);return}
      e.fx=lx/ld;e.fy=ly/ld;steerMove(e,lk[0],lk[1],D.spd*.8,dt,true);return}
    case 'SEARCH':{
      aiHouse(e,dt);e.t-=dt;
      if(seen&&target){aiToChase(e,target);return}
      if(heard&&target){aiToInvestigate(e,[target.x,target.y],'ruido');return}
      e.searchA+=dt*2.2;e.fx=Math.cos(e.searchA);e.fy=Math.sin(e.searchA);e.vx=e.vy=0;
      if(e.t<=0){e.state='RETURN';e.lastKnown=null;e.phase=0;e.hit=false}
      return}
    case 'CHASE':{
      // perdeu o alvo de vista: vai até a última posição conhecida em vez de seguir "por mágica"
      if(seen&&target){e.lostT=0;e.lastKnown=[target.x,target.y]}
      else e.lostT=(e.lostT||0)+dt;
      if(e.lostT>1.1&&e.lastKnown){aiToInvestigate(e,e.lastKnown,'perdeu-de-vista');return}
      return aiBase(e,dt)}
  }
  return aiBase(e,dt);
};

/* --- rótulos "?" acima de quem investiga/procura --- */
const aiDrawBase=drawEnemy;
drawEnemy=function(e){
  aiDrawBase(e);
  if(e.state==='INVESTIGATE'||e.state==='SEARCH'){
    const q=S(e.x,e.y,30);ctx.fillStyle='#ffd34a';ctx.fillRect(q[0]-3,q[1]-1,6,8);
    ctx.fillStyle='#16203a';ctx.fillRect(q[0]-1,q[1]+1,2,3);ctx.fillRect(q[0]-1,q[1]+6,2,1);
  }
  if(e.riposte>0){const q=S(e.x,e.y,30);ctx.globalAlpha=.55+.45*Math.sin(tNow*18);ctx.fillStyle='#ff5a3c';ctx.fillRect(q[0]-5,q[1]-2,10,2);ctx.globalAlpha=1}
};

/* --- RIPOSTA: aparada perfeita deixa o inimigo vulnerável --- */
const aiHitPlayerBase=hitPlayer;
hitPlayer=function(dmg,e){
  const parried=aiHitPlayerBase(dmg,e);
  if(parried===true&&e&&e.state!=='DEAD'){e.riposte=1.6;floatText(P.x,P.y-.6,'APARADO!','xp')}
  return parried;
};
const aiDamageBase=damageEnemy;
damageEnemy=function(e,a,sx,sy,kb){
  if(e&&e.riposte>0&&e.state!=='DEAD'){a*=2.4;kb=(kb||3)*1.5;e.riposte=0;floatText(e.x,e.y-.5,'RIPOSTA!','xp');hitstop=Math.max(hitstop,.12);shake=Math.max(shake,5);e.t=Math.max(e.t||0,.6);if(e.state!=='RECOVER'){e.state='RECOVER'}}
  return aiDamageBase(e,a,sx,sy,kb);
};
window.vaAI={sees:aiSees,hears:aiHears,los:aiLOS,toInvestigate:aiToInvestigate,log:(window.AI_LOG=[])};
