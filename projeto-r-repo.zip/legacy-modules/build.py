import base64,re,sys
src='/mnt/user-data/uploads/projeto-r-v0_14_cloud_com_extras_0_25.html'
html=open(src,encoding='utf8').read()
def rep(old,new,count=1):
    global html
    n=html.count(old)
    if n<1: print('NAO ACHOU:',old[:70]);sys.exit(1)
    html=html.replace(old,new,count)
# DevTools F2 -> F3
rep("e.code==='F2'","e.code==='F3'")
rep("F2 = DevTools","F3 = DevTools · Esc = Pausa (salvar/carregar/reiniciar)")
rep("DEV · F2","DEV · F3")
rep("[F2/Esc] fechar","[F3/Esc] fechar")
rep("F1 debug · F2 DevTools","F1 debug · F3 DevTools · Esc pausa")
# ordem de desenho: caixas
rep("items.push({k:t.x+t.y+1,f:()=>drawTree(t)})","items.push({k:t.x+t.y+1,b:t.ruin?[t.x-.1,t.y-.1,t.x+1.1,t.y+1.1]:[t.x+.2,t.y+.2,t.x+.8,t.y+.8],f:()=>drawTree(t)})")
rep("items.push({k:h.x+h.w/2+h.y+h.h/2,f:()=>drawHouse(h)})","items.push({k:h.x+h.w/2+h.y+h.h/2,b:[h.x,h.y,h.x+h.w,h.y+h.h],f:()=>drawHouse(h)})")
rep("items.push({k:l.x+l.y+1,f:()=>drawLamp(l)})","items.push({k:l.x+l.y+1,b:[l.x+.3,l.y+.3,l.x+.7,l.y+.7],f:()=>drawLamp(l)})")
rep("items.push({k:p.x+p.y,f:()=>drawPickup(p)});\n  items.push({k:NPC.x+NPC.y,f:drawNpc});\n  for(const e of enemies)items.push({k:e.x+e.y,f:()=>drawEnemy(e)});\n  items.push({k:P.x+P.y,","items.push({k:p.x+p.y,b:[p.x-.15,p.y-.15,p.x+.15,p.y+.15],f:()=>drawPickup(p)});\n  items.push({k:NPC.x+NPC.y,b:[NPC.x-.25,NPC.y-.25,NPC.x+.25,NPC.y+.25],f:drawNpc});\n  for(const e of enemies)items.push({k:e.x+e.y,b:[e.x-.3,e.y-.3,e.x+.3,e.y+.3],f:()=>drawEnemy(e)});\n  items.push({k:P.x+P.y,b:[P.x-.25,P.y-.25,P.x+.25,P.y+.25],")
rep("items.sort((a,b)=>a.k-b.k);for(const it of items)it.f();","if(window.vaSort){window.vaExtraItems(items);window.vaSort(items)}else items.sort((a,b)=>a.k-b.k);for(const it of items)it.f();")
va=open('/home/claude/assets/va_visual.js').read()
pano=base64.b64encode(open('/home/claude/assets/pano.jpg','rb').read()).decode()
ban=base64.b64encode(open('/home/claude/assets/banner.png','rb').read()).decode()
va+=open('/home/claude/assets/va_saga.js').read()+open('/home/claude/assets/va_ai.js').read()+open('/home/claude/assets/va_chars.js').read()
va=va.replace('__PANO__',pano).replace('__BANNER__',ban)
i=html.rfind('})();')
out=html[:i]+va+'\n'+html[i:]
out=out.replace('Vadronia · <b style=\\"color:#e0b85c\\">Grünwald</b> · vertical slice 0.14.0','<b style=\\"color:#e0b85c\\">Grünwald</b> · versão 0.14.6')
open('/home/claude/projeto-r-v0_14_6-vadronia.html','w',encoding='utf8').write(out)
print('ok',len(out))
