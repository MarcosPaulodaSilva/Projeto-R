
/* =====================================================================
   0.14.3 — CAMINHO DA COROA (arco principal) + CRÔNICA (tecla C)
   Nada de medidor mágico: o final depende de feitos reais, cartas respondidas,
   apoio de uma Grande Casa, reconhecimento e legitimidade. Canon preservado:
   nenhuma Casa é boa ou má, Henry/Julian não são vilões, o mistério antigo fica em aberto.
   ===================================================================== */
const SAGA_V=1;
const saga={bond:0,approvalReplies:0,house:null,stance:null,promise:false,honest:false,invited:false,guild:false,
  nights:0,shadowKills:0,eliteKills:0,hardNights:0,notes:0,inbox:[],read:{},lastLetterDay:0,asked:false,married:false,marriedDay:0};
let sagaNightSeen=false,sagaNightDowns=0,sagaPrevDay=T.day,sagaClock=0,sagaPrevDown=new Map();

const SG_QUESTS=['voices','herbs','forge','road','oldstone'];
const sgDone=id=>QUESTS[id]&&QUESTS[id].state==='done';
const sgQuestsDone=()=>SG_QUESTS.filter(sgDone).length;
const sgRuins=()=>!!(ruins&&ruins.cleared);
const sgHouses={
  falkenberg:{name:'Falkenberg',sym:'o falcão diante da montanha',desc:'Defesa, fortalezas, disciplina.',need:'3 noites defendidas e 3 elites derrotados',ok:()=>saga.nights>=3&&saga.eliteKills>=3,stance:['julian','neutral']},
  eichenwald:{name:'Eichenwald',sym:'o carvalho com raízes',desc:'Campos, florestas e abastecimento.',need:'doar 80 coroas ao abastecimento de Grünwald',ok:()=>true,cost:80,stance:['henry','neutral']},
  silberhain:{name:'Silberhain',sym:'a lua prateada entre galhos',desc:'Arquivos, história e estudo de ruínas.',need:'vencer as Ruínas e concluir a Pedra que Não Tem Nome',ok:()=>sgRuins()&&sgDone('oldstone'),stance:['neutral']}
};
const sgStanceName={henry:'Henry',julian:'Julian',neutral:'o processo das Casas'};
function sgApproval(){let a=saga.approvalReplies;if(sgRuins())a++;if(saga.nights>=4)a++;if(saga.promise)a++;if(saga.house)a++;return a}
function sgStanceOk(){if(!saga.house||!saga.stance)return false;return sgHouses[saga.house].stance.includes(saga.stance)}
function sgChecklist(){
  const rows=[
    ['Vínculo com Nicasia (cartas respondidas com sinceridade)',saga.bond,7],
    ['Aprovação de Beatrice',sgApproval(),4],
    ['Apoio de uma Grande Casa',saga.house?1:0,1],
    ['Reconhecimento popular (reputação)',reputation,10],
    ['Feitos: Ruínas vencidas',sgRuins()?1:0,1],
    ['Feitos: noites defendidas sem civis feridos',saga.nights,4],
    ['Feitos: elites da estrada derrotados',saga.eliteKills,2],
    ['Legitimidade: sucessão resolvida de forma coerente',sgStanceOk()?1:0,1]
  ];
  return rows.map(r=>({label:r[0],have:r[1],need:r[2],ok:r[1]>=r[2]}));
}
const sgReady=()=>sgChecklist().every(r=>r.ok);

const SG_LETTERS=[
 {id:'n1',from:'Nicasia Morigan',tag:'Capital',cond:()=>sgQuestsDone()>=5,noGap:true,title:'Um nome que se repete nos relatórios',
  text:'Não nos conhecemos. Meu nome é Nicasia e, no castelo, cuido de organizar os relatórios que chegam das estradas e dos vilarejos. O nome de Grünwald apareceu duas vezes na mesma semana, e isso quase nunca acontece: uma vez por um problema resolvido, outra por alguém que ajudou sem pedir nada em troca. Disseram que o senhor é um forasteiro. Prefiro relatos honestos aos bonitos. Como estão as coisas aí, de verdade?',
  choices:[{label:'Contar tudo, inclusive o que deu errado.',bond:2,flag:'honest',reply:'Ela vai gostar de ouvir os fracassos junto com os acertos.'},
           {label:'Responder só com os feitos.',bond:1,reply:'Uma carta educada, mas curta.'}]},
 {id:'g1',from:'Guilda de Vadronia',tag:'Guilda',cond:()=>sgRuins(),title:'Registro de explorador',
  text:'Os arquivos da Guilda registram a exploração de uma ruína antiga perto de Grünwald, antes dada como perdida. A Guilda mantém contratos, informação e reconhecimento para quem prova seu valor em campo. O registro é gratuito. Não prometemos fama, apenas trabalho e testemunhas.',
  choices:[{label:'Registrar-se na Guilda.',rep:2,flag:'guild',reply:'Seu nome agora consta nos livros da Guilda.'},
           {label:'Registrar-se, mas continuar servindo Grünwald primeiro.',rep:1,rel:{konrad:1},reply:'Konrad aprova a lealdade ao vilarejo.'}]},
 {id:'n2',from:'Nicasia Morigan',tag:'Capital',cond:()=>saga.read.n1&&saga.read.g1&&saga.nights>=2,title:'Sobre as noites',
  text:'Li o relatório de Grünwald sobre as noites. Algo escuro surge na escuridão e os moradores se escondem em casa. Fico pensando em quantos ainda não tiveram a sorte de ter alguém por perto. Costumo imaginar o pior antes de acreditar no melhor, é um defeito. Diga-me o que realmente funciona aí: luz? guardas? as casas?',
  choices:[{label:'Explicar: as casas protegem, e Konrad guarda o vilarejo.',bond:1,reply:'Ela anota cada detalhe.'},
           {label:'Convidá-la, um dia, a ver Grünwald com os próprios olhos.',bond:2,flag:'invited',reply:'Ela vai levar o convite a sério.'}]},
 {id:'b1',from:'Beatrice Morigan',tag:'Coroa',cond:()=>saga.read.n2&&sgRuins()&&reputation>=6,title:'O interesse das Grandes Casas',
  text:'Escrevo como governante e como mãe. Falkenberg, Eichenwald e Silberhain notaram os relatos de Grünwald. Nenhuma delas é amiga ou inimiga por natureza, cada uma pede algo diferente de quem deseja seu apoio. Meus filhos Henry e Julian têm reivindicações legítimas e eu não quero ver a corte quebrada por uma disputa. Se alguém de fora lhe perguntasse quem deveria herdar a coroa, o que o senhor diria?',
  choices:[{label:'Que Henry e Julian se entendam e que as Casas decidam pelo processo.',approval:2,stance:'neutral',reply:'Beatrice respeita quem não ignora nenhum dos filhos.'},
           {label:'Que Henry, mais administrativo, parece preparado.',approval:1,stance:'henry',reply:'Uma opinião honesta, mas Julian merece respeito igual.'},
           {label:'Que Julian, mais corajoso, inspira os soldados.',approval:1,stance:'julian',reply:'Uma opinião honesta, mas Henry merece respeito igual.'}],
  unlocksHouses:true},
 {id:'n3',from:'Nicasia Morigan',tag:'Capital',cond:()=>saga.read.b1&&!!saga.house,title:'Quando as estradas estiverem seguras',
  text:'Soube que uma Grande Casa o apoia. Fico contente, e um pouco inquieta: apoio político costuma custar caro, e quem o oferece raramente é só gentil. Diga-me uma coisa: o companheiro que viaja com o senhor, esse tal Konrad, ele cuida do senhor ou apenas o segue? Não, não precisa responder isso, era brincadeira, mais ou menos.',
  choices:[{label:'Prometer ir à capital quando a estrada estiver segura.',bond:2,promise:true,reply:'Ela guardará essa promessa.'},
           {label:'Responder com leveza e mudar de assunto.',bond:1,reply:'Ela ri, desconfiada.'}]},
 {id:'b2',from:'Beatrice Morigan',tag:'Coroa',cond:()=>sgReady()&&saga.read.n3,noGap:false,title:'Convite ao Castelo Morigan',
  text:'Os relatórios, as Casas e minha filha concordam em algo raro: o senhor merece uma audiência. Venha ao Castelo Morigan. Não prometo um resultado, apenas que será ouvido por quem decide. Heinrich teria gostado de conhecê-lo.',
  choices:[{label:'Aceitar a audiência.',audience:true,reply:'A estrada para a capital se abre.'}]}
];
const SG_NOTES=[
 'Os relatos dizem que ninguém ficou ferido nas últimas noites. Obrigada por não mandar só os números.',
 'Pedi que arquivassem seus relatos junto aos da Guilda. Meu irmão Henry perguntou quem era o senhor.',
 'Julian leu sobre as ruínas e quer saber se o senhor luta com escudo. Disse que sim, por você.',
 'Kian me pediu para desenhar a ponte de Grünwald. Eu nunca a vi, então descreva-a melhor.'
];
function sgLetterDef(id){return SG_LETTERS.find(l=>l.id===id)}

/* --------- métricas de conduta --------- */
const sgKillBase=killEnemy;
killEnemy=function(e){const alive=e&&e.state!=='DEAD';sgKillBase(e);if(alive&&e&&e.state==='DEAD'){if(e.type==='shadow')saga.shadowKills++;if(e.elite)saga.eliteKills++}};
function sgTickDay(){
  if(isNight()&&livingNightThreats().length)sagaNightSeen=true;
  for(const n of villagers){const d=(n.down||0)>0,was=sagaPrevDown.get(n.id)||false;if(d&&!was)sagaNightDowns++;sagaPrevDown.set(n.id,d)}
  if(T.day!==sagaPrevDay){
    if(sagaNightSeen){if(sagaNightDowns===0){saga.nights++;toast('Noite defendida: ninguém ficou ferido.')}else saga.hardNights++}
    sagaNightSeen=false;sagaNightDowns=0;sagaPrevDay=T.day;
  }
}
function sgDeliver(l){
  if(saga.inbox.some(m=>m.id===l.id))return;
  saga.inbox.push({id:l.id,day:T.day});saga.lastLetterDay=T.day;
  toast(`Carta de ${l.from} — abra a Crônica (C)`);sfx('pick');sgBadge();
}
function sgPoll(){
  for(const l of SG_LETTERS){
    if(saga.inbox.some(m=>m.id===l.id))continue;
    if(!l.noGap&&T.day-saga.lastLetterDay<1)continue;
    if(l.cond()){sgDeliver(l);return}
  }
  // bilhetes breves a cada duas noites defendidas além da 2ª
  const due=Math.floor(Math.max(0,saga.nights-2)/2);
  if(saga.notes<Math.min(due,SG_NOTES.length)&&T.day-saga.lastLetterDay>=1&&saga.read.n2){
    const id='note'+saga.notes;saga.notes++;
    SG_LETTERS.push({id,from:'Nicasia Morigan',tag:'Bilhete',title:'Um bilhete',text:SG_NOTES[saga.notes-1],note:true,choices:[{label:'Agradecer e responder com sinceridade.',bond:1,reply:'Ela guardará o bilhete.'}]});
    sgDeliver(SG_LETTERS[SG_LETTERS.length-1]);
  }
}
function sgBadge(){
  let el=$('vaBadge');if(!el){el=document.createElement('div');el.id='vaBadge';el.style.cssText='position:absolute;left:50%;top:6px;transform:translateX(-50%);padding:2px 6px;font-size:8px;color:#f1e3b8;background:#172a5a;border:1px solid #c9a24a;z-index:20;pointer-events:none;display:none';$('stage').appendChild(el)}
  const un=saga.inbox.filter(m=>!saga.read[m.id]).length;
  el.textContent=`✉ ${un} carta(s) nova(s) — C`;el.style.display=un&&!saga.married?'block':'none';
}
const sgUpdBase=update;
update=function(dt){sgUpdBase(dt);sagaClock+=dt;if(sagaClock>=.5){sagaClock=0;if(!DG){sgTickDay();sgPoll()}}};

/* --------- Atos --------- */
function sgAct(){
  if(saga.married)return{n:6,title:'Epílogo — Casa Morigan',goal:'Vadronia segue; você ajuda a escrever o que vem depois.'};
  if(saga.inbox.some(m=>m.id==='b2'&&saga.read.b2))return{n:5,title:'Ato V — Castelo Morigan',goal:'A audiência está marcada. Peça a mão de Nicasia, se for este o seu caminho.'};
  if(saga.house)return{n:4,title:'Ato IV — Casa e Coroa',goal:'Cumpra a lista de legitimidade abaixo. Beatrice o chamará quando estiver pronto.'};
  if(saga.read.b1)return{n:3,title:'Ato III — As Três Casas',goal:'Escolha uma Grande Casa cuja posição combine com a sua resposta sobre a sucessão.'};
  if(sgRuins()||saga.read.n1)return{n:2,title:'Ato II — Feitos da Estrada',goal:'Vença as Ruínas, defenda Grünwald nas noites e alcance reputação 6.'};
  return{n:1,title:'Ato I — Um Nome em Grünwald',goal:`Conclua as 5 missões do vilarejo (${sgQuestsDone()}/5). Um dia alguém notará.`};
}

/* --------- Painel da Crônica --------- */
(function sgUI(){
  const st=document.createElement('style');
  st.textContent=`#sagaPanel,#sagaPanel .sgBody{font-size:9px !important;line-height:1.35}#sagaPanel h2{font-size:12px !important}#sagaPanel .close{font-size:8px !important}#sagaPanel .sgBox{margin:4px 0;padding:4px 6px;border:1px solid #3a4a7a;background:rgba(20,28,56,.55)}
  #sagaPanel .sgBox.unread{border-color:#c9a24a}#sagaPanel .sgOk{color:#8fd98f}#sagaPanel .sgNo{color:#e0a070}
  #sagaPanel .sgBtn{display:block;margin:3px 0;padding:3px 6px;border:1px solid #b8923f;background:linear-gradient(#26407e,#172a5a);cursor:pointer;color:#efe6cf}
  #sagaPanel .sgBtn:hover{background:#35549a}#sagaPanel .sgBtn.off{opacity:.45;cursor:not-allowed}
  #sagaPanel h3{margin:6px 0 2px;color:#f1e3b8}#sagaPanel .sgBody{height:calc(100% - 20px);overflow:auto}
  #vaEnd{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;justify-content:center;z-index:80;text-align:center;padding:8px;background:radial-gradient(circle at 50% 30%,rgba(40,70,150,.55),rgba(5,8,18,.97));color:#efe6cf;pointer-events:auto}
  #vaEnd h1{font-family:Georgia,serif;letter-spacing:5px;color:#f1e3b8;margin:2px 0;font-size:22px}#vaEnd{overflow:auto}#vaEnd p{max-width:430px;font-size:9px;line-height:1.5;margin:4px 0}
  #vaEnd .sgBtn{margin-top:8px;padding:4px 12px;border:2px solid #c9a24a;background:linear-gradient(#26407e,#172a5a);cursor:pointer;font-size:9px}`;
  document.head.appendChild(st);
  const p=document.createElement('div');p.id='sagaPanel';p.className='panel';
  p.innerHTML='<span class="close">[C/Esc] fechar</span><h2>CRÔNICA — CAMINHO DA CROWN</h2><div id="sagaBody" class="sgBody"></div>'.replace('CROWN','COROA');
  $('stage').appendChild(p);
  const e=document.createElement('div');e.id='vaEnd';$('stage').appendChild(e);
  ['mousedown','mouseup','click'].forEach(ev=>e.addEventListener(ev,x=>x.stopPropagation()));
})();
const sgCloseBase=closePanels;
closePanels=function(){sgCloseBase();$('sagaPanel').classList.remove('show')};
function sgToggle(){
  if(openPanel==='sagaPanel'){closePanels();return}
  closeDialogue();closePanels();openPanel='sagaPanel';$('sagaPanel').classList.add('show');sgRender();
}
function sgApplyChoice(l,i){
  const c=l.choices[i];if(saga.read[l.id])return;
  saga.read[l.id]=true;
  if(c.bond)saga.bond+=c.bond;if(c.approval)saga.approvalReplies+=c.approval;if(c.rep)reputation+=c.rep;
  if(c.rel)for(const k in c.rel)relations[k]=(relations[k]||0)+c.rel[k];
  if(c.flag)saga[c.flag]=true;if(c.promise)saga.promise=true;if(c.stance)saga.stance=c.stance;
  if(c.reply)toast(c.reply);
  autosave();updateMetaHud();sgBadge();sgRender();
}
function sgChooseHouse(id){
  const h=sgHouses[id];if(saga.house||!h)return;
  if(!h.ok()||!h.stance.includes(saga.stance))return;
  if(h.cost){if(P.gold<h.cost)return toast('Coroas insuficientes');P.gold-=h.cost}
  saga.house=id;reputation+=2;toast(`${h.name} passa a apoiá-lo.`);sfx('pick');
  autosave();updateMetaHud();sgRender();
}
function sgPropose(){
  if(!sgReady()||saga.married)return;
  saga.married=true;saga.marriedDay=T.day;autosave();sgBadge();closePanels();sgEpilogue();
}
function sgEpilogue(){
  const hn=saga.house?sgHouses[saga.house].name:'nenhuma Casa';
  const st={neutral:'Henry e Julian aceitaram que a sucessão fosse decidida pelo processo das Casas, e a corte não se quebrou.',henry:'Henry assumiu as tarefas administrativas do reino, com Julian ao lado comandando as fronteiras.',julian:'Julian assumiu a defesa das fronteiras, com Henry ao lado cuidando da administração.'}[saga.stance]||'';
  const h={falkenberg:'Falkenberg ergueu o falcão sobre as fortalezas do vale.',eichenwald:'Eichenwald encheu os celeiros de Vadronia.',silberhain:'Silberhain abriu seus arquivos para estudar as ruínas sem nome, sem nunca decifrá-las.'}[saga.house]||'';
  const el=$('vaEnd');running=false;
  el.innerHTML=`<img src="data:image/png;base64,__BANNER__" style="height:46px;width:auto;image-rendering:pixelated;margin-top:2px"><h1>CASAMENTO REAL</h1>
  <p>No Castelo Morigan, sob o azul profundo e a prata, Beatrice aceitou o pedido diante da corte. Nicasia disse que sim sem deixar de ser quem era: honesta, observadora e organizada até no próprio casamento.</p>
  <p>${h} ${st}</p>
  <p>Ninguém explicou o mistério das ruínas, e ninguém descobriu quem amaldiçoou o rei Heinrich. Mas a estrada para Grünwald estava segura, e a luz das casas ficou acesa naquela noite.</p>
  <p style="color:#b9c8e8">Dia ${saga.marriedDay} · Nível ${P.level} · ${saga.nights} noites defendidas · apoio de ${hn}</p>
  <div class="sgBtn" id="vaEndBtn">Continuar em Vadronia</div>`;
  el.style.display='flex';
  $('vaEndBtn').onclick=()=>{el.style.display='none';running=true;toast('O reino continua. Você também.')};
}
function sgRender(){
  const a=sgAct(),b=$('sagaBody'),cl=sgChecklist();let h='';
  h+=`<h3>${a.title}</h3><div class="muted">${a.goal}</div>`;
  h+='<h3>Legitimidade</h3><div>'+cl.map(r=>`<div class="${r.ok?'sgOk':'sgNo'}">${r.ok?'✔':'✖'} ${r.label} <span class="muted">(${Math.min(r.have,r.need)}/${r.need})</span></div>`).join('')+'</div>';
  if(saga.read.b1&&!saga.house){
    h+='<h3>As Três Casas</h3>';
    for(const id in sgHouses){const H=sgHouses[id],okS=H.stance.includes(saga.stance),okD=H.ok();
      h+=`<div class="sgBox"><b>${H.name}</b> <span class="muted">— ${H.desc} Símbolo: ${H.sym}.</span><div class="muted">Exige: ${H.need}.</div><div class="muted">Posição na sucessão: aceita ${H.stance.map(s=>sgStanceName[s]).join(' ou ')}.${okS?'':' (incompatível com a sua resposta)'}</div><div class="sgBtn ${okS&&okD?'':'off'}" data-house="${id}">Buscar o apoio de ${H.name}</div></div>`}
  }else if(saga.house){h+=`<div class="sgBox">Apoio: <b>${sgHouses[saga.house].name}</b>. Posição na sucessão: ${sgStanceName[saga.stance]}.</div>`}
  if(saga.inbox.some(m=>m.id==='b2')&&saga.read.b2&&!saga.married){
    h+=`<h3>Audiência</h3><div class="sgBox">Você está diante de Beatrice e Nicasia no Castelo Morigan.<div class="sgBtn" data-propose="1">Pedir a mão de Nicasia</div><div class="muted">Não é obrigatório. O reino continua sem isso.</div></div>`}
  h+='<h3>Correspondência</h3>';
  if(!saga.inbox.length)h+='<div class="muted">Nenhuma carta ainda. Ajude Grünwald, e o mundo notará.</div>';
  for(const m of [...saga.inbox].reverse()){
    const l=sgLetterDef(m.id);if(!l)continue;const rd=saga.read[l.id];
    h+=`<div class="sgBox ${rd?'':'unread'}"><b>${l.title}</b> <span class="muted">— ${l.from} · dia ${m.day}</span><div>${l.text}</div>`;
    if(!rd)h+=l.choices.map((c,i)=>`<div class="sgBtn" data-reply="${l.id}:${i}">${c.label}</div>`).join('');else h+='<div class="muted">Respondida.</div>';
    h+='</div>';
  }
  b.innerHTML=h;
  b.querySelectorAll('[data-reply]').forEach(x=>x.onclick=ev=>{ev.stopPropagation();const[id,i]=x.dataset.reply.split(':');const l=sgLetterDef(id);if(l){sgApplyChoice(l,+i);if(l.choices[+i].audience)sgRender()}});
  b.querySelectorAll('[data-house]').forEach(x=>x.onclick=ev=>{ev.stopPropagation();if(!x.classList.contains('off'))sgChooseHouse(x.dataset.house)});
  b.querySelectorAll('[data-propose]').forEach(x=>x.onclick=ev=>{ev.stopPropagation();sgPropose()});
}
addEventListener('keydown',e=>{if(e.repeat||e.code!=='KeyC'||e.ctrlKey||e.metaKey)return;if(window.__vaPaused||$('over').style.display!=='none'||talking||DG)return;e.preventDefault();sgToggle()});

/* --------- save / load --------- */
const sgSaveBase=saveData;
saveData=function(){const d=sgSaveBase();d.saga=JSON.parse(JSON.stringify({v:SAGA_V,s:saga,extra:SG_LETTERS.filter(l=>l.note).map(l=>({id:l.id,text:l.text}))}));return d};
const sgLoadBase=loadSave;
loadSave=function(){
  const ok=sgLoadBase();
  if(ok){try{const d=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');if(d&&d.saga&&d.saga.s){
    for(const l of SG_LETTERS.filter(l=>l.note))SG_LETTERS.splice(SG_LETTERS.indexOf(l),1);
    for(const x of (d.saga.extra||[]))SG_LETTERS.push({id:x.id,from:'Nicasia Morigan',tag:'Bilhete',title:'Um bilhete',text:x.text,note:true,choices:[{label:'Agradecer e responder com sinceridade.',bond:1,reply:'Ela guardará o bilhete.'}]});
    Object.assign(saga,d.saga.s);sagaPrevDay=T.day;sgBadge()}}catch(_){}}
  return ok;
};

/* --------- título: continuar x novo jogo --------- */
(function sgTitle(){
  let d=null;try{d=JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(_){}
  if(!d||!d.player)return;
  const sb=$('startBtn'),h=d.worldTime?`Dia ${d.worldTime.day} · ${String(Math.floor(d.worldTime.hour)).padStart(2,'0')}:00`:'';
  sb.textContent=`CONTINUAR · ${h} · Nv ${d.player.level}`;
  const nb=document.createElement('div');nb.className='go';nb.id='newBtn';nb.textContent='NOVO JOGO';nb.style.marginTop='6px';nb.style.filter='saturate(.6)';
  sb.insertAdjacentElement('afterend',nb);let armed=false;
  nb.onclick=e=>{e.stopPropagation();if(!armed){armed=true;nb.textContent='Clique de novo: APAGA o save atual';return}try{localStorage.removeItem(SAVE_KEY)}catch(_){}location.reload()};
  $('continueHint').textContent='Há um save local. "Continuar" retoma de onde parou; "Novo jogo" recomeça no Dia 1.';
})();

/* --------- DEV: atalhos do arco (console: vaSaga.dev('n1')) --------- */
window.vaSaga={saga,checklist:sgChecklist,act:sgAct,poll:sgPoll,render:sgRender,
  dev(step){
    if(step==='quests')for(const id of SG_QUESTS)QUESTS[id].state='done';
    if(step==='ruins'){ruins.cleared=true;worldFlags.ruinsCleared=true}
    if(step==='nights'){saga.nights=6;saga.eliteKills=3;reputation=Math.max(reputation,10)}
    if(step==='all'){this.dev('quests');this.dev('ruins');this.dev('nights');P.level=Math.max(P.level,7);P.gold+=200}
    saga.lastLetterDay=-9;sgPoll()
  }};
window.vaSagaUnread=()=>saga.inbox.filter(m=>!saga.read[m.id]).length;
sgBadge();
