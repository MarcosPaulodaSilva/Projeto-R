
/* =====================================================================
   0.14.6 — PERSONAGENS NO ESTILO VADRONIA (sombreados, botas, colarinho, mãos)
   Substitui human(): mesma assinatura, mesmo retorno; só o desenho muda.
   ===================================================================== */
function vcRGB(h){const n=parseInt(h.slice(1),16);return[(n>>16)&255,(n>>8)&255,n&255]}
function vcMix(h,t,a){const c=vcRGB(h),d=t===0?[0,0,0]:[255,255,255],f=Math.abs(a);return'#'+c.map((v,i)=>Math.round(v+(d[i]-v)*f).toString(16).padStart(2,'0')).join('')}
const vcDark=(h,a)=>vcMix(h,0,a),vcLite=(h,a)=>vcMix(h,1,a);
human=function(x,y,o){
  const p=S(x,y),sx=p[0],sy=p[1],f=o.flash>0;
  const col=c=>f?'#ffffff':c,bob=Math.round(Math.sin(o.walk||0)*(o.moving?1:0)),sd=o.sdir>0?1:-1,away=o.away;
  shadow(sx,sy,6,3);
  const lo=Math.round(Math.sin(o.walk||0)*(o.moving?2:0)),a=Math.max(0,lo),b=Math.max(0,-lo);
  const boot='#3a2a1e',pants=o.pants||'#433b34',tun=o.tunic||'#4a6a98',skin=o.skin||'#e0b48a',hair=o.hair||'#4a3322';
  // pernas + botas
  rect(sx-3,sy-5+a,2,5-a,col(pants));rect(sx+1,sy-5+b,2,5-b,col(vcDark(pants,.18)));
  rect(sx-3,sy-2+a,2,2-a>0?2-a:0,col(boot));rect(sx+1,sy-2+b,2,2-b>0?2-b:0,col(boot));
  rect(sx-4,sy-1+a,3,1,col(boot));rect(sx+1,sy-1+b,3,1,col(boot));
  // tronco: luz à esquerda, sombra à direita, barra do manto
  rect(sx-4,sy-12+bob,8,8,col(tun));
  rect(sx-4,sy-12+bob,2,8,col(vcLite(tun,.14)));rect(sx+2,sy-12+bob,2,8,col(vcDark(tun,.2)));
  rect(sx-4,sy-5+bob,8,1,col(vcDark(tun,.32)));
  // cinto com fivela
  rect(sx-4,sy-7+bob,8,1,col(o.belt||'#30251b'));rect(sx-(sd>0?0:1),sy-7+bob,2,1,col('#d9b24a'));
  // colarinho/cachecol
  if(o.scarf)rect(sx-4,sy-13+bob,8,2,col(o.scarf));else rect(sx-3,sy-13+bob,6,1,col(vcLite(tun,.32)));
  // braços e mãos
  const swing=o.moving?Math.round(Math.sin((o.walk||0)+3.14)*1.5):0;
  rect(sx-5,sy-11+bob+swing,1,5,col(vcDark(tun,.12)));rect(sx+4,sy-11+bob-swing,1,5,col(vcDark(tun,.24)));
  rect(sx-5,sy-7+bob+swing,1,1,col(skin));rect(sx+4,sy-7+bob-swing,1,1,col(skin));
  // pescoço e cabeça (pele com meia-sombra)
  rect(sx-1,sy-14+bob,2,1,col(vcDark(skin,.2)));
  rect(sx-3,sy-20+bob,6,6,col(skin));rect(sx+(sd>0?1:-3),sy-19+bob,2,5,col(vcDark(skin,.1)));
  // cabelo: franja, laterais e topo
  rect(sx-3,sy-21+bob,6,3,col(hair));rect(sx-4,sy-20+bob,1,3,col(hair));rect(sx+3,sy-20+bob,1,3,col(hair));
  rect(sx-2,sy-22+bob,4,1,col(vcLite(hair,.18)));
  if(away){rect(sx-3,sy-18+bob,6,4,col(hair));rect(sx-2,sy-15+bob,4,1,col(vcDark(hair,.2)))}
  else{rect(sx-3,sy-18+bob,6,1,col(hair));
    rect(sx+(sd>0?0:-2),sy-16+bob,1,1,'#1a1410');rect(sx+(sd>0?2:0)-(sd>0?1:0),sy-16+bob,1,1,'#1a1410');
    rect(sx+(sd>0?1:-1),sy-14+bob,1,1,col(vcDark(skin,.3)))}
  return{sx,sy,bob};
};
