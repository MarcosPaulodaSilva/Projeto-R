
/* =====================================================================
   0.14.1 — PASSE VISUAL DE VADRONIA
   Redesenha o mundo no estilo das reference sheets (telhados de ardósia azul,
   enxaimel, pedra, coníferas, bandeiras Morigan, lanternas). Só renderização:
   nenhuma colisão, IA ou regra de jogo é alterada.
   ===================================================================== */
window.PROJETO_R_BUILD='0.14.2-vadronia';window.__setHour=h=>{T.hour=h};
const VA_PANO=new Image();VA_PANO.src='data:image/jpeg;base64,__PANO__';
const VA_BANNER=new Image();VA_BANNER.src='data:image/png;base64,__BANNER__';
const VA_GR=['#4f8a3a','#5a9642','#468034','#548f3e'],VA_FL=['#ece0f4','#e07a8a','#f2d46a','#86aee6'];
const VA_WATER=['#2d6aa3','#3a7db6','#29609a'];
function vaPlaza(x,y){return x>=6&&x<=10&&y>=11&&y<=16}
function vaLerp2(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]}

drawBg=function(){
  const g=ctx.createLinearGradient(0,0,0,H);
  g.addColorStop(0,'#5d86b8');g.addColorStop(.34,'#86a9c8');g.addColorStop(.6,'#2f4d3b');g.addColorStop(1,'#16261c');
  ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  if(VA_PANO.complete&&VA_PANO.naturalWidth){
    const pw=W+90,ph=Math.round(pw*141/480),px=Math.round(-45-clamp(cam.x*.04,-34,34)),py=Math.round(-4-clamp(cam.y*.02,-10,10));
    ctx.imageSmoothingEnabled=false;ctx.drawImage(VA_PANO,px,py,pw,ph);
    const f=ctx.createLinearGradient(0,py+ph-46,0,py+ph);f.addColorStop(0,'rgba(47,77,59,0)');f.addColorStop(1,'rgba(47,77,59,1)');
    ctx.fillStyle=f;ctx.fillRect(0,py+ph-46,W,47);
  }
};

drawTiles=function(){
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){
    const sx=Math.round(toX(x,y)+ox),sy=Math.round(toY(x,y)+oy);
    if(sx<-20||sx>W+20||sy<-20||sy>H+8)continue;
    const g=ground[y*N+x],h=hsh(x,y),h2=hsh(x*5+1,y*3+7);let c;
    if(g===0){c=VA_GR[(h*4)|0];if(hsh(x>>1,y>>1)>.7)c='#4a8036'}
    else if(g===1){c=vaPlaza(x,y)?(((x+y)&1)?'#868b96':'#7c818c'):(h>.5?'#a88d62':'#9f8559')}
    else if(g===2)c=VA_WATER[((h+tNow*.25)*3|0)%3];
    else c=h>.5?'#8d6439':'#82592f';
    ctx.fillStyle=c;ctx.strokeStyle=c;ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(sx+16,sy+8);ctx.lineTo(sx,sy+16);ctx.lineTo(sx-16,sy+8);ctx.closePath();ctx.fill();ctx.stroke();
    if(g===0){
      if(h>.62){rect(sx-5+(h*20|0)%9,sy+5+(h*50|0)%5,1,2,'#3b6a2c');rect(sx+3,sy+8,1,2,'#78a955')}
      if(h2>.93){const fc=VA_FL[(h*97|0)%4],fx=sx-4+(h*31|0)%8,fy=sy+6+(h*17|0)%4;rect(fx,fy,2,2,fc);rect(fx,fy+2,1,1,'#2f5a26')}
    }else if(g===1){
      if(vaPlaza(x,y)){
        line(sx-8,sy+4,sx+8,sy+12,'#6a6f7a');line(sx+8,sy+4,sx-8,sy+12,'#6a6f7a');
        if(h>.6)rect(sx-2,sy+7,3,2,'#8f9a77');
      }else{
        if(h>.55)rect(sx-4+(h*30|0)%8,sy+7,2,1,'#7a6644');
        if(h2>.8)rect(sx+2,sy+9,2,1,'#c2ab80');
        if(h2<.12)rect(sx-3,sy+6,2,2,'#8a8a8e');
      }
    }else if(g===2){
      if(Math.sin(tNow*2+x*1.3+y*.7)>.86)rect(sx-5,sy+7,6,1,'#b4d6f0');
      // espuma nas margens
      if(x>0&&ground[y*N+x-1]!==2&&ground[y*N+x-1]!==3)rect(sx-10,sy+6,3,1,'#cfe6f5');
      if(x<N-1&&ground[y*N+x+1]!==2&&ground[y*N+x+1]!==3)rect(sx+8,sy+6,3,1,'#cfe6f5');
    }else{
      line(sx-8,sy+4,sx+8,sy+12,'#503620');line(sx-4,sy+2,sx+12,sy+10,'#503620');line(sx-12,sy+6,sx+4,sy+14,'#503620');
      rect(sx-1,sy+7,1,1,'#b8895a');
    }
  }
};

drawTree=function(t){
  if(t.ruin)return drawRuinGate(t);
  const p=S(t.x+.5,t.y+.5),cx=p[0],cy=p[1],k=t.k;
  if(k<.07){poly([[cx-7,cy],[cx-5,cy-7],[cx+2,cy-9],[cx+7,cy-3],[cx+8,cy]],'#7b8088');poly([[cx+2,cy-9],[cx+7,cy-3],[cx+8,cy],[cx+1,cy]],'#5d626b');rect(cx-4,cy-6,4,1,'#a2a6ad');rect(cx-6,cy-3,3,2,'#4f7a3a');return}
  if(k<.12){ // arbusto florido
    poly([[cx-7,cy],[cx-6,cy-6],[cx,cy-9],[cx+6,cy-6],[cx+7,cy]],'#3f7a38');poly([[cx,cy-9],[cx+6,cy-6],[cx+7,cy],[cx+1,cy]],'#336a2f');
    const fc=VA_FL[(k*400|0)%4];rect(cx-4,cy-6,2,2,fc);rect(cx+2,cy-7,2,2,fc);rect(cx-1,cy-3,2,2,fc);rect(cx+4,cy-3,2,2,'#f2d46a');return}
  const sc=.8+k*.55;
  rect(cx-1,cy-7,3,7,'#4a3322');rect(cx+1,cy-7,1,7,'#382618');
  let c1,c2,hi;
  if(k>.975){c1='#b5451f';c2='#d9622e';hi='#f0894a'}          // ruivo
  else if(k>.94){c1='#c18a1c';c2='#e0a82c';hi='#f4cc5c'}      // dourado
  else if(k>.55){c1='#24523a';c2='#2f6b4a';hi='#4a8a64'}      // abeto azulado
  else{c1='#2b5a38';c2='#3a7448';hi='#559a62'}                // abeto
  tri(cx,cy-4,Math.round(24*sc),Math.round(14*sc),c1,c2);
  tri(cx,cy-13*sc|0,Math.round(18*sc),Math.round(13*sc),c1,c2);
  tri(cx,cy-21*sc|0,Math.round(11*sc),Math.round(12*sc),c1,c2);
  rect(cx+Math.round(1*sc),cy-20*sc|0,2,1,hi);rect(cx+Math.round(3*sc),cy-12*sc|0,2,1,hi);
};

function vaBanner(x,y,sw){ // bandeira Morigan: azul profundo, estrela prateada e montanha
  const w=7,h=15;rect(x-4,y,9,1,'#6b5430');
  rect(x-3+sw,y+1,w,h,'#233f8c');rect(x-3+sw,y+1,1,h,'#1b3274');rect(x+3+sw,y+1,1,h,'#2d4ea6');
  rect(x-3+sw,y+h+1,w,1,'#c9a24a');poly([[x-3+sw,y+h+1],[x+4+sw,y+h+1],[x+sw,y+h+4]],'#c9a24a');
  rect(x+sw,y+3,1,3,'#e9eef7');rect(x-1+sw,y+4,3,1,'#e9eef7');
  poly([[x-2+sw,y+12],[x+sw,y+8],[x+3+sw,y+12]],'#c4cfe0');rect(x+sw,y+8,1,1,'#ffffff');
}
let vaLampIdx=0;
drawLamp=function(l){
  const p=S(l.x+.5,l.y+.5),cx=p[0],cy=p[1];
  rect(cx-2,cy-2,4,2,'#585c64');rect(cx-1,cy-17,2,15,'#2a2420');rect(cx-1,cy-17,1,15,'#3a322c');
  const li=lamps.indexOf(l);
  rect(cx-3,cy-23,6,6,'#d9a441');rect(cx-2,cy-22,4,4,isNight()?'#fff0b0':'#f5d27a');rect(cx-3,cy-24,6,1,'#2a2420');rect(cx-3,cy-17,6,1,'#2a2420');rect(cx-1,cy-26,2,2,'#2a2420');
  if(li%2===0){rect(cx+1,cy-15,6,1,'#2a2420');vaBanner(cx+3,cy-14,Math.round(Math.sin(tNow*1.6+li)*0.8))}
};

function vaFace(a,b,n,wh,col,door,seed){
  poly([a,b,[b[0],b[1]-wh],[a[0],a[1]-wh]],col);
  // fundação de pedra
  poly([a,b,[b[0],b[1]-5],[a[0],a[1]-5]],'#7a7e86');
  line(a[0],a[1]-5,b[0],b[1]-5,'#5d6068');
  const T='#3d2b1e';
  for(let i=0;i<=n;i++){const t=i/n,px=Math.round(lerp(a[0],b[0],t)),py=Math.round(lerp(a[1],b[1],t));rect(px,py-wh,1,wh-5,T)}
  line(a[0],a[1]-wh,b[0],b[1]-wh,T);line(a[0],a[1]-wh+1,b[0],b[1]-wh+1,T);line(a[0],a[1]-wh*.5|0,b[0],b[1]-wh*.5|0,T);
  for(let i=0;i<n;i++){
    const t=(i+.5)/n,px=Math.round(lerp(a[0],b[0],t)),py=Math.round(lerp(a[1],b[1],t));
    if(door&&i===(n>>1)){
      rect(px-3,py-14,8,14,'#2f1f13');rect(px-2,py-13,6,13,'#6a4426');rect(px,py-13,1,13,'#3d2815');rect(px+2,py-7,1,1,'#e9c25a');
      rect(px-3,py-15,8,1,'#7a7e86');
    }else{
      rect(px-3,py-wh+8,7,8,'#2b2018');rect(px-2,py-wh+9,5,6,isNight()?'#ffd77a':'#86aed0');
      rect(px,py-wh+9,1,6,'#2b2018');rect(px-2,py-wh+12,5,1,'#2b2018');
      if(!isNight())rect(px-2,py-wh+9,2,1,'#c6def0');
      // jardineira de flores
      rect(px-3,py-wh+16,7,2,'#5a3d22');
      const fc=VA_FL[(seed+i)%4];rect(px-2,py-wh+15,1,1,fc);rect(px,py-wh+15,1,1,'#e07a8a');rect(px+2,py-wh+15,1,1,fc);
    }
  }
}
function vaRoofSlope(P0,P1,M,col,dark,lite){
  poly([P0,P1,M],col);
  const rows=7;
  for(let i=1;i<rows;i++){
    const t=i/rows,a=vaLerp2(P0,M,t),b=vaLerp2(P1,M,t);
    line(Math.round(a[0]),Math.round(a[1]),Math.round(b[0]),Math.round(b[1]),dark);
    // juntas das telhas alternadas
    const segs=Math.max(2,Math.round((rows-i)*.9));
    for(let s=0;s<segs;s++){const u=(s+(i&1?.5:0))/segs,q=vaLerp2(a,b,u);if(u>0&&u<1)rect(Math.round(q[0]),Math.round(q[1])-1,1,2,dark)}
  }
  line(P0[0],P0[1],P1[0],P1[1],'#2a1d18');
  line(P0[0],P0[1],M[0],M[1],lite);
}
drawHouse=function(h){
  const wh=26,A=S(h.x,h.y+h.h),B=S(h.x+h.w,h.y+h.h),C=S(h.x+h.w,h.y);
  const seed=(h.x*7+h.y*3)|0;
  vaFace(A,B,h.w,wh,'#e8dcbc',h.w===3&&h.x===4?0:0,seed);
  vaFace(B,C,h.h,wh,'#c8b78e',1,seed+1);
  const Lc=S(h.x-.4,h.y+h.h+.4,wh),Bc=S(h.x+h.w+.4,h.y+h.h+.4,wh),Rc=S(h.x+h.w+.4,h.y-.4,wh),M=S(h.x+h.w/2,h.y+h.h/2,wh+18);
  const lite='rgba(255,255,255,.28)';
  vaRoofSlope(Lc,Bc,M,h.roof,h.roof2,lite);vaRoofSlope(Bc,Rc,M,h.roof2,'rgba(0,0,0,.28)','rgba(255,255,255,.12)');
  line(Bc[0],Bc[1],Rc[0],Rc[1],'#2a1d18');
  // chaminé + fumaça
  rect(M[0]+5,M[1]-3,6,11,'#6e6a66');rect(M[0]+4,M[1]-5,8,2,'#4b4743');rect(M[0]+9,M[1]-3,2,11,'#58544f');
  for(let i=0;i<3;i++){const u=((tNow*.35+i/3+seed*.13)%1),a=Math.max(0,1-u);ctx.globalAlpha=a*.5;rect(M[0]+7+Math.sin(u*5+i)*3,M[1]-8-u*20,3+u*3|0,3+u*3|0,'#d9dde4');}
  ctx.globalAlpha=1;
};

/* ---------- título e HUD no estilo Morigan ---------- */
(function vaUI(){
  const st=document.createElement('style');
  st.textContent=`
  #over{background:linear-gradient(180deg,rgba(8,12,26,.35) 0%,rgba(8,12,26,.72) 55%,rgba(5,8,18,.94) 100%),url(data:image/jpeg;base64,__PANO__) center top/cover no-repeat !important;image-rendering:pixelated}
  #over h1{font-family:Georgia,'Times New Roman',serif;font-size:30px;letter-spacing:6px;color:#f1e3b8;text-shadow:0 2px 0 #1b2a5c,0 0 12px rgba(120,160,255,.45)}
  #over .vaSub{font-family:Georgia,serif;font-size:10px;letter-spacing:3px;color:#b9c8e8;margin:0 0 6px;text-transform:uppercase}
  #over .vaCrest{width:34px;height:auto;image-rendering:pixelated;margin-bottom:2px;filter:drop-shadow(0 2px 0 rgba(0,0,0,.6))}
  #over .go{border:2px solid #c9a24a;background:linear-gradient(#26407e,#172a5a);color:#f1e3b8;box-shadow:0 0 0 1px #000,inset 0 0 0 1px #4a68b8}
  .bar{box-shadow:0 0 0 1px #8a6b3a !important;background:#0d1220 !important}
  #dlg{background:linear-gradient(#141b33,#0e1426) !important;border:2px solid #b8923f !important;box-shadow:0 0 0 1px #000,inset 0 0 0 1px #2d3f7a !important}
  .panel{background:linear-gradient(#121a30,#0c1224) !important;border-color:#b8923f !important}
  `;
  document.head.appendChild(st);
  const o=$('over'),h1=o&&o.querySelector('h1');
  if(h1){h1.textContent='VADRONIA';
    h1.insertAdjacentHTML('beforebegin','<img class="vaCrest" src="data:image/png;base64,__BANNER__" alt="">');
    h1.insertAdjacentHTML('afterend','<div class="vaSub">Reino das Montanhas e Florestas</div>')}
  document.title='Vadronia — Grünwald e Ruínas (0.14.6)';
})();

/* =====================================================================
   0.14.2 — correções: ordem de desenho, sombras, props reais, pausa
   ===================================================================== */

/* ---------- sol e sombras ---------- */
function vaSun(){
  const h=T.hour;
  if(h<5.8||h>=20.2)return{a:0,dx:0,dy:0,len:0,night:true};
  const t=clamp((h-6)/14,0,1),day=Math.min(1,(h-5.8)/1.4,(20.2-h)/1.4);
  let a=.38*clamp(day,0,1);
  if(typeof weatherType==='function'&&weatherType()==='rain')a*=.45;
  return{a,dx:lerp(-1.5,1.5,t),dy:.32,len:.55+1.0*Math.pow(Math.abs(t-.5)*2,1.6),night:false};
}
shadow=function(x,y,rx,ry){
  const s=vaSun();
  ctx.fillStyle=s.night?'rgba(4,8,20,.34)':`rgba(12,22,44,${(.18+s.a*.6).toFixed(3)})`;
  ctx.beginPath();ctx.ellipse(x+s.dx*1.6,y+.5,rx,ry,0,0,6.283);ctx.fill();
};
function vaPoly(ctx2,pts){ctx2.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx2.lineTo(pts[i][0],pts[i][1]);ctx2.closePath()}
function vaCastShadows(){
  const s=vaSun();
  ctx.save();
  // contato ambiente (sempre): pé de árvores e base das casas
  ctx.fillStyle=s.night?'rgba(4,8,20,.30)':'rgba(10,20,40,.22)';
  for(const t of trees){
    const p=S(t.x+.5,t.y+.5);if(p[0]<-40||p[0]>W+40||p[1]<-30||p[1]>H+60)continue;
    const sc=.8+t.k*.55,small=t.k<.12;
    ctx.beginPath();ctx.ellipse(p[0],p[1]+1,(small?6:8)*(small?1:sc),(small?2.5:3.4)*(small?1:sc),0,0,6.283);ctx.fill();
  }
  if(s.a>0){
    ctx.fillStyle=`rgba(12,22,44,${s.a.toFixed(3)})`;
    // sombras longas das árvores: um único path => sem acúmulo de alpha
    ctx.beginPath();
    for(const t of trees){
      if(t.ruin||t.k<.07)continue;
      const p=S(t.x+.5,t.y+.5);if(p[0]<-60||p[0]>W+60||p[1]<-30||p[1]>H+70)continue;
      const sc=t.k<.12?.5:.8+t.k*.55,ht=(t.k<.12?10:30*sc)*s.len,tx=p[0]+s.dx*ht*.9,ty=p[1]+s.dy*ht*.5,w=(t.k<.12?4:7)*sc;
      vaPoly(ctx,[[p[0]-w,p[1]],[tx-w*.35,ty-1],[tx+w*.35,ty+1],[p[0]+w,p[1]+1]]);
    }
    ctx.fill();
    // casas: varredura do footprint pelo vetor do sol
    ctx.beginPath();
    for(const h of houses){
      const c=[S(h.x,h.y),S(h.x+h.w,h.y),S(h.x+h.w,h.y+h.h),S(h.x,h.y+h.h)];
      if(c[1][0]<-120||c[3][0]>W+120)continue;
      const k=(26+8)*s.len,v=[s.dx*k*.62,s.dy*k*.5],c2=c.map(q=>[q[0]+v[0],q[1]+v[1]]);
      vaPoly(ctx,c);
      for(let i=0;i<4;i++){const j=(i+1)%4;vaPoly(ctx,[c[i],c[j],c2[j],c2[i]])}
      vaPoly(ctx,c2);
    }
    ctx.fill();
    // postes (lampiões, bandeiras)
    ctx.beginPath();
    for(const l of lamps){const p=S(l.x+.5,l.y+.5),ht=22*s.len;vaPoly(ctx,[[p[0]-1,p[1]],[p[0]+s.dx*ht*.9-1,p[1]+s.dy*ht*.5],[p[0]+s.dx*ht*.9+1,p[1]+s.dy*ht*.5+1],[p[0]+1,p[1]+1]])}
    ctx.fill();
  }
  ctx.restore();
}
const vaTilesBase=drawTiles;
drawTiles=function(){vaTilesBase();if(!DG)vaCastShadows()};

/* ---------- props reais (deixam de ser linhas flutuantes) ---------- */
(function vaSolidProps(){
  // poço = obstáculo de 1 tile; cercas e postes usam colisão fina (abaixo), não tiles inteiros
  const wx=Math.floor(props.well[0]),wy=Math.floor(props.well[1]);if(solid[wy*N+wx]===0&&ground[wy*N+wx]!==2)solid[wy*N+wx]=2;
  for(const l of lamps)if(solid[l.y*N+l.x]===2)solid[l.y*N+l.x]=0; // poste não bloqueia o tile da rua inteiro
})();
const VA_POSTS=lamps.map(l=>[l.x+.5,l.y+.5]);
function vaSegDist(px,py,f){const dx=f[2]-f[0],dy=f[3]-f[1],l2=dx*dx+dy*dy||1;let t=((px-f[0])*dx+(py-f[1])*dy)/l2;t=t<0?0:t>1?1:t;return Math.hypot(px-(f[0]+dx*t),py-(f[1]+dy*t))}
const vaBlockedBase=blocked;
blocked=function(x,y,r){
  if(vaBlockedBase(x,y,r))return true;
  if(DG)return false;
  for(const f of props.fences)if(vaSegDist(x,y,f)<r*.7+.06)return true;   // cerca: parede fina
  for(const q of VA_POSTS)if(Math.hypot(x-q[0],y-q[1])<r*.6+.12)return true; // poste: só a base
  return false;
};
function vaFenceSeg(f){
  const a=S(f[0],f[1]),b=S(f[2],f[3]),n=Math.max(2,Math.round(Math.hypot(b[0]-a[0],b[1]-a[1])/9));
  // trilhos atrás, postes na frente
  for(const hh of [10,5]){line(a[0],a[1]-hh,b[0],b[1]-hh,'#5a3d25');line(a[0],a[1]-hh+1,b[0],b[1]-hh+1,'#8a6340')}
  for(let i=0;i<=n;i++){
    const x=Math.round(lerp(a[0],b[0],i/n)),y=Math.round(lerp(a[1],b[1],i/n));
    rect(x-1,y-13,3,13,'#6d4b2f');rect(x,y-13,1,13,'#8a6340');rect(x-1,y-14,3,1,'#a8825a');
  }
}
function vaCrate(c){const q=S(c[0],c[1]);
  poly([[q[0]-5,q[1]-5],[q[0],q[1]-8],[q[0]+5,q[1]-5],[q[0],q[1]-2]],'#a17646');
  poly([[q[0]-5,q[1]-5],[q[0],q[1]-2],[q[0],q[1]+3],[q[0]-5,q[1]]],'#7a5432');
  poly([[q[0]+5,q[1]-5],[q[0],q[1]-2],[q[0],q[1]+3],[q[0]+5,q[1]]],'#5f4025');
  line(q[0]-5,q[1]-5,q[0],q[1]-2,'#c29a63');line(q[0],q[1]-2,q[0],q[1]+3,'#3f2a17')}
function vaBench(b){const q=S(b[0],b[1]);
  rect(q[0]-7,q[1]-6,14,2,'#8a6340');rect(q[0]-7,q[1]-4,14,1,'#5a3d25');
  rect(q[0]-6,q[1]-3,2,4,'#3f2a17');rect(q[0]+4,q[1]-3,2,4,'#3f2a17');rect(q[0]-7,q[1]-9,14,1,'#6d4b2f')}
function vaWell(){const q=S(props.well[0],props.well[1]);
  for(let i=0;i<7;i++){const w=14-Math.abs(i-3)*0;rect(q[0]-7,q[1]-7+i,w,1,i<2?'#9a9ea6':(i%2?'#7c8089':'#868a93'))}
  ctx.fillStyle='#173a5c';ctx.beginPath();ctx.ellipse(q[0],q[1]-6,5,2,0,0,6.283);ctx.fill();
  rect(q[0]-6,q[1]-17,2,11,'#5a3d25');rect(q[0]+4,q[1]-17,2,11,'#5a3d25');
  poly([[q[0]-9,q[1]-17],[q[0],q[1]-23],[q[0]+9,q[1]-17]],'#2c4c8c');rect(q[0]-9,q[1]-17,18,1,'#1b2f60');
  rect(q[0]-1,q[1]-16,1,6,'#c9b27a')}
function vaStone(){const q=S(oldStone.x,oldStone.y);
  poly([[q[0]-5,q[1]],[q[0]-4,q[1]-10],[q[0]+2,q[1]-14],[q[0]+6,q[1]]],'#6e7478');poly([[q[0]+2,q[1]-14],[q[0]+6,q[1]],[q[0]+1,q[1]]],'#565c60');
  rect(q[0]-2,q[1]-9,1,1,'#58e0f0');rect(q[0],q[1]-6,2,1,'#58e0f0');rect(q[0]-2,q[1]-4,1,1,'#58e0f0');
  if(QUESTS.oldstone.state==='active')drawQuestMarker(oldStone.x,oldStone.y,'active')}
function vaHerb(h){const q=S(h.x,h.y);for(let i=0;i<3;i++){line(q[0],q[1]-i,q[0]-3+i*3,q[1]-6,'#87b76a');rect(q[0]-4+i*3,q[1]-7,3,2,'#a9d98c')}
  if(QUESTS.herbs.state==='active')drawQuestMarker(h.x,h.y,'active')}

/* ---------- ordem de desenho correta (caixas, não só x+y) ---------- */
function vaExtraItems(items){
  const bx=(x,y,r)=>[x-r,y-r,x+r,y+r];
  for(const f of props.fences){
    const n=Math.max(1,Math.ceil(Math.hypot(f[2]-f[0],f[3]-f[1])/1.0));
    for(let i=0;i<n;i++){const g=[lerp(f[0],f[2],i/n),lerp(f[1],f[3],i/n),lerp(f[0],f[2],(i+1)/n),lerp(f[1],f[3],(i+1)/n)];
      items.push({k:(g[0]+g[1]+g[2]+g[3])/2,b:[Math.min(g[0],g[2])-.08,Math.min(g[1],g[3])-.08,Math.max(g[0],g[2])+.08,Math.max(g[1],g[3])+.08],f:()=>vaFenceSeg(g)})}}
  for(const c of props.crates)items.push({k:c[0]+c[1],b:bx(c[0],c[1],.25),f:()=>vaCrate(c)});
  for(const b of props.benches)items.push({k:b[0]+b[1],b:bx(b[0],b[1],.35),f:()=>vaBench(b)});
  items.push({k:props.well[0]+props.well[1],b:bx(props.well[0],props.well[1],.5),f:vaWell});
  items.push({k:oldStone.x+oldStone.y,b:bx(oldStone.x,oldStone.y,.3),f:vaStone});
  for(const h of herbs)if(!h.taken)items.push({k:h.x+h.y-.2,b:bx(h.x,h.y,.1),f:()=>vaHerb(h)});
  for(const p of lootDrops)items.push({k:p.x+p.y,b:bx(p.x,p.y,.15),f:()=>drawLoot(p)});
  for(const n of villagers){if(n.inside)continue;items.push({k:n.x+n.y,b:bx(n.x,n.y,.25),f:()=>drawVillager(n)})}
}
function vaSort(items){
  const n=items.length,E=.001;
  for(const it of items){if(!it.b){const h=it.k/2;it.b=[h-.2,h-.2,h+.2,h+.2]}}
  const out=[],indeg=new Int32Array(n),adj=Array.from({length:n},()=>[]);
  for(let i=0;i<n;i++){const A=items[i].b;
    for(let j=i+1;j<n;j++){const B=items[j].b;
      const aB=A[2]<=B[0]+E||A[3]<=B[1]+E,bB=B[2]<=A[0]+E||B[3]<=A[1]+E;
      if(aB&&!bB){adj[i].push(j);indeg[j]++}else if(bB&&!aB){adj[j].push(i);indeg[i]++}
    }}
  const done=new Uint8Array(n);let left=n;
  while(left){
    let best=-1;
    for(let i=0;i<n;i++)if(!done[i]&&indeg[i]===0&&(best<0||items[i].k<items[best].k))best=i;
    if(best<0)for(let i=0;i<n;i++)if(!done[i]&&(best<0||items[i].k<items[best].k))best=i; // ciclo: desempata por x+y
    done[best]=1;left--;out.push(items[best]);for(const j of adj[best])indeg[j]--;
  }
  for(let i=0;i<n;i++)items[i]=out[i];
}
drawLocalWorld=function(){}; /* agora tudo isso entra na lista ordenada (vaExtraItems) */

/* ---------- menu de pausa (ESC) ---------- */
(function vaPause(){
  const st=document.createElement('style');
  st.textContent=`
  #vaPause{position:absolute;inset:0;display:none;align-items:center;justify-content:center;flex-direction:column;background:rgba(5,8,18,.72);z-index:60;pointer-events:auto;cursor:default}
  #vaPause h2{margin:0 0 6px;font-family:Georgia,serif;font-size:18px;letter-spacing:4px;color:#f1e3b8;text-shadow:0 2px 0 #1b2a5c}
  #vaPause .vb{width:150px;margin:2px 0;padding:4px 0;text-align:center;font-size:9px;color:#efe6cf;border:2px solid #b8923f;background:linear-gradient(#26407e,#172a5a);box-shadow:0 0 0 1px #000,inset 0 0 0 1px #4a68b8;cursor:pointer}
  #vaPause .vb:hover{background:linear-gradient(#35549a,#1f3672);color:#fff}
  #vaPause .vb.off{opacity:.4;cursor:not-allowed}
  #vaPause .vb.danger{border-color:#b8433d}
  #vaPause p{margin:6px 0 0;font-size:8px;color:#b9c8e8;min-height:10px;text-align:center}`;
  document.head.appendChild(st);
  const el=document.createElement('div');el.id='vaPause';
  el.innerHTML='<h2>PAUSA</h2><div class="vb" data-a="resume">Continuar (Esc)</div><div class="vb" data-a="save">Salvar jogo</div><div class="vb" data-a="load">Carregar jogo</div><div class="vb" data-a="settings">Configurações</div><div class="vb danger" data-a="restart">Reiniciar tudo</div><p id="vaPauseMsg"></p>';
  $('stage').appendChild(el);
  let open=false,armed=0;
  const msg=t=>{$('vaPauseMsg').textContent=t};
  const refresh=()=>{
    const hasSave=!!localStorage.getItem(SAVE_KEY);
    el.querySelector('[data-a=save]').classList.toggle('off',!!DG);
    el.querySelector('[data-a=load]').classList.toggle('off',!!DG||!hasSave);
    el.querySelector('[data-a=restart]').textContent='Reiniciar tudo';armed=0;
    msg(DG?'Dentro das Ruínas não é possível salvar ou carregar.':'');
  };
  function openPause(){if(open||!running)return;open=true;window.__vaPaused=true;running=false;refresh();el.style.display='flex'}
  function closePause(){if(!open)return;open=false;window.__vaPaused=false;el.style.display='none';running=true}
  window.vaPause={open:openPause,close:closePause,get isOpen(){return open}};
  ['mousedown','mouseup','click','contextmenu'].forEach(ev=>el.addEventListener(ev,e=>{e.stopPropagation();if(ev==='contextmenu')e.preventDefault()}));
  el.addEventListener('click',e=>{
    const b=e.target.closest('.vb');if(!b||b.classList.contains('off'))return;
    const a=b.dataset.a;
    if(a==='resume')closePause();
    else if(a==='save'){autosave();const l=el.querySelector('[data-a=load]');if(localStorage.getItem(SAVE_KEY))l.classList.remove('off');msg('Jogo salvo.')}
    else if(a==='load'){if(loadSave()){refreshDerived();updateMetaHud();msg('Jogo carregado.');closePause();toast('Jogo carregado')}else msg('Nenhum save encontrado.')}
    else if(a==='settings'){closePause();togglePanel('settings')}
    else if(a==='restart'){
      if(!armed){armed=1;b.textContent='Clique de novo para APAGAR o save e recomeçar';return}
      try{localStorage.removeItem(SAVE_KEY)}catch(_){}
      location.reload();
    }
  });
  addEventListener('keydown',e=>{
    if(e.code!=='Escape'||e.repeat)return;
    if(e.defaultPrevented&&!open)return; // outro sistema (DevTools) já tratou este ESC
    if(open){e.preventDefault();e.stopImmediatePropagation();closePause();return}
    const busy=openPanel||talking||(typeof MERGE_DEV!=='undefined'&&MERGE_DEV.open)||$('over').style.display!=='none';
    if(busy)return; // ESC fecha painel/diálogo como antes
    e.preventDefault();e.stopImmediatePropagation();openPause();
  },true);
})();
window.__vaTP=(x,y)=>{P.x=x;P.y=y;cam.x=toX(x,y);cam.y=toY(x,y)-8};
window.vaExtraItems=vaExtraItems;window.vaSort=vaSort;

$('hint').textContent='RDFG mover · Mouse mirar/atacar · Espaço esquivar · Dir/Shift defender · T interagir · E tônico · I J K M painéis · Esc pausa · F3 DevTools';
