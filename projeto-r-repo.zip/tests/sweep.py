import asyncio,sys
from playwright.async_api import async_playwright
src=sys.argv[1]
spots=[('plaza',8.5,13.5,10),('norte',8.5,6.5,10),('casaNO',5,8,10),('casaE',12.5,10,10),('ponte',19.5,13.5,10),('perigo',24.5,13.5,10),('portal',26.5,6.8,10),('sul',9,19.5,10),('casasul',12,19,10),('noite',8.5,13.5,21.3),('manha',8.5,13.5,6.6),('tarde',8.5,13.5,18.6)]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+src);await pg.click('#startBtn');await pg.wait_for_timeout(300)
        for n,x,y,h in spots:
            await pg.evaluate(f"window.__setHour({h});window.__vaTP({x},{y})");await pg.wait_for_timeout(500)
            await pg.screenshot(path=f'sw_{n}.png')
        print('errors:',errs[:6]);await b.close()
asyncio.run(main())
