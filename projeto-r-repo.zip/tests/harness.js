// Harness Node para Projeto R (0.14): roda o JS do HTML com DOM falso e testa invariantes.
const fs=require('fs'),vm=require('vm');
const file=process.argv[2]||'/mnt/user-data/uploads/projeto-r-v0_14_cloud_com_extras_0_25.html';
const html=fs.readFileSync(file,'utf8');
const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const mk=()=>{const f=function(){};const p=new Proxy(f,{get(t,k){if(k===Symbol.toPrimitive)return()=>0;if(k==='length')return 0;if(k==='width'||k==='height')return 480;if(k==='getBoundingClientRect')return()=>({left:0,top:0,width:480,height:270});if(k==='style'||k==='classList'||k==='dataset')return p;if(k==='children'||k==='childNodes')return[];if(k==='querySelectorAll')return()=>[];if(k==='value')return'1';if(k==='textContent'||k==='innerHTML')return t['_'+String(k)]||'';return p},set(t,k,v){t['_'+String(k)]=v;return true},apply(){return p}});return p};
const store={};let rafCb=null;
const sandbox={console,Math,JSON,Date,Object,Array,Set,Map,WeakMap,Number,String,Boolean,Symbol,Error,Promise,parseInt,parseFloat,isNaN,isFinite,Float32Array,Uint8Array,Uint8ClampedArray,Int32Array,Float64Array,
 document:{getElementById:()=>mk(),createElement:()=>mk(),body:mk(),head:mk(),documentElement:mk(),addEventListener(){}, querySelector:()=>mk(),querySelectorAll:()=>[]},
 localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}},
 addEventListener(){},requestAnimationFrame:cb=>{rafCb=cb;return 1},performance:{now:()=>0},
 setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,innerWidth:1280,innerHeight:720,devicePixelRatio:1,Image:function(){return mk()},navigator:{},AudioContext:undefined,webkitAudioContext:undefined,Audio:function(){return mk()}};
sandbox.window=sandbox;sandbox.globalThis=sandbox;
vm.createContext(sandbox);
const hook=`;globalThis.__R={P,T,get enemies(){return enemies},villagers,companion,NPC,isNight,livingNightThreats,hitVillager,get DG(){return DG},worldFlags,get inventory(){return inventory},saveData,get running(){return running},blocked:(x,y,r)=>blocked(x,y,r),lamps,props,hitPlayer,damageEnemy,floatTexts,solid,N,ground,houses,setRunning:v=>{running=v},devAction:a=>mergeDevAction(a),get enemyShots(){return mergeEnemyShots}};`;
let body=scripts.join('\n');const li=body.lastIndexOf('})();');const code=body.slice(0,li)+hook+'\n'+body.slice(li);
vm.runInContext(code,sandbox,{filename:'game.js'});
module.exports={sandbox,R:()=>sandbox.__R,step:(n=1,dt=1/60)=>{for(let i=0;i<n;i++){const cb=rafCb;if(!cb)throw new Error('sem rAF');rafCb=null;sandbox.__t=(sandbox.__t||0)+dt*1000;cb(sandbox.__t)}},store};
