import asyncio,sys
from playwright.async_api import async_playwright
src=sys.argv[1]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+src);await pg.wait_for_timeout(600)
        await pg.screenshot(path='c9_title.png')
        await pg.wait_for_timeout(1500)
        await pg.click('#introGate');await pg.wait_for_timeout(800)
        await pg.evaluate('IntroCinematic.finish(true)');await pg.wait_for_timeout(2500)
        await pg.screenshot(path='c9_menu.png')
        await pg.click('#startBtn');await pg.wait_for_timeout(2500)
        await pg.screenshot(path='c9_after_start.png')
        res=await pg.evaluate('''()=>{
          const C=window.vaCollide,r=.3,out={};
          const cross=(x,y0,y1)=>{let y=y0;const st=Math.sign(y1-y0)*.05;for(let i=0;i<200;i++){const ny=y+st;if(!C.blocked(x,ny,r))y=ny;else break}return y};
          out.fenceLine=[6,6.8,7.5].every(x=>C.blocked(x,6.2,r));
          out.fromSouth=cross(6.8,7.6,5);out.fromNorth=cross(6.8,5.2,7.6);
          out.endPass=!C.blocked(8.4,6.2,r);
          out.f2=[6.5,7.5].every(x=>C.blocked(x,20.6,r));out.f3=[11.5,12.5,13].every(x=>C.blocked(x,21,r));
          out.posts=C.lamps.map(l=>[!C.blocked(l.x+1,l.y+.5,r),!C.blocked(l.x+.5,l.y+1,r),C.blocked(l.x+.5,l.y+.5,r)]);
          out.build=window.PROJETO_R_BUILD;return out}''')
        print(res);print('errors:',errs[:5]);await b.close()
asyncio.run(main())
