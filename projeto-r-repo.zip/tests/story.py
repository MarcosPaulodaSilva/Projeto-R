import asyncio,sys
from playwright.async_api import async_playwright
src=sys.argv[1]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+src);await pg.click('#startBtn');await pg.wait_for_timeout(300)
        S=lambda js:pg.evaluate(js)
        async def reply(i=0):
            await pg.keyboard.press('KeyC');await pg.wait_for_timeout(150)
            btn=pg.locator('#sagaBody [data-reply]').nth(i);await btn.click();await pg.wait_for_timeout(150)
            await pg.keyboard.press('KeyC');await pg.wait_for_timeout(100)
        log=lambda k,v:print(k,'=>',v)
        log('ato inicial',(await S("vaSaga.act()"))['title'])
        await S("vaSaga.dev('quests')");await pg.wait_for_timeout(100);log('carta n1 chegou',await S("vaSagaUnread()"))
        await pg.screenshot(path='st_n1.png')
        await pg.keyboard.press('KeyC');await pg.wait_for_timeout(200);await pg.screenshot(path='st_panel.png');await pg.keyboard.press('KeyC')
        await reply(0)
        await S("vaSaga.dev('ruins')");await reply(0)  # g1
        await S("vaSaga.dev('nights')");await reply(1)  # n2 convidar
        await S("vaSaga.dev('nights')");await reply(0)  # b1 neutral
        log('ato',(await S("vaSaga.act()"))['title'])
        await pg.keyboard.press('KeyC');await pg.wait_for_timeout(200);await pg.screenshot(path='st_houses.png')
        await pg.locator('[data-house=silberhain]').click();await pg.wait_for_timeout(150);await pg.keyboard.press('KeyC')
        log('casa',await S("vaSaga.saga.house"))
        await S("vaSaga.dev('all')");await reply(0)  # n3
        for i in range(4):
            await S("vaSaga.saga.nights+=2;vaSaga.dev('nights')")
            if await S("vaSagaUnread()")>0:await reply(0)
        log('bond/approval/pronto',await S("[vaSaga.saga.bond,vaSaga.checklist().filter(r=>!r.ok).map(r=>r.label)]"))
        await S("vaSaga.dev('all')")
        if await S("vaSagaUnread()")>0:await reply(0)
        await pg.keyboard.press('KeyC');await pg.wait_for_timeout(200);await pg.screenshot(path='st_final.png')
        has=await pg.locator('[data-propose]').count();log('botao pedir mao',has)
        if has:
            await pg.locator('[data-propose]').click();await pg.wait_for_timeout(300);await pg.screenshot(path='st_end.png')
        log('casado',await S("vaSaga.saga.married"))
        await pg.click('#vaEndBtn');await pg.wait_for_timeout(200)
        # save/load roundtrip
        
        s=await S("JSON.parse(localStorage.getItem('projetoR_grunwald_v02')||'{}').saga&&1");log('saga salva',s)
        print('errors:',errs[:6]);await b.close()
asyncio.run(main())
