import asyncio,sys
from playwright.async_api import async_playwright
src=sys.argv[1]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+src);await pg.click('#startBtn');await pg.wait_for_timeout(300)
        r={}
        vis=lambda sel:pg.evaluate(f"getComputedStyle(document.querySelector('{sel}')).display")
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200);r['pausa abre']=await vis('#vaPause')
        t0=await pg.evaluate("document.getElementById('ctime').textContent");await pg.wait_for_timeout(600)
        r['tempo parado']=t0==await pg.evaluate("document.getElementById('ctime').textContent")
        await pg.screenshot(path='fn_pause.png')
        await pg.click('[data-a=save]');r['msg save']=await pg.inner_text('#vaPauseMsg')
        r['save existe']=await pg.evaluate("!!localStorage.getItem('projetoR_grunwald_v02')")
        await pg.evaluate("window.__vaTP(9,18)");r['x antes load']=await pg.evaluate("window.__vaX&&1")
        await pg.click('[data-a=load]');await pg.wait_for_timeout(300)
        r['load fecha pausa']=await vis('#vaPause')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(100);r['esc abre']=await vis('#vaPause');await pg.keyboard.press('Escape');await pg.wait_for_timeout(100);r['esc fecha']=await vis('#vaPause')
        await pg.keyboard.press('F2');await pg.wait_for_timeout(200);r['F2 dev (deve ser none)']=await vis('#devPanel')
        await pg.keyboard.press('F3');await pg.wait_for_timeout(300);r['F3 dev']=await vis('#devPanel');await pg.screenshot(path='fn_dev.png')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200);r['esc fecha dev']=await vis('#devPanel');r['esc nao abriu pausa junto']=await vis('#vaPause')
        await pg.keyboard.press('KeyI');await pg.wait_for_timeout(150);await pg.keyboard.press('Escape');await pg.wait_for_timeout(150);r['esc fecha inventario, sem pausa']=await vis('#vaPause')
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(150);r['pausa reabre']=await vis('#vaPause')
        await pg.keyboard.press('KeyM');await pg.wait_for_timeout(150);await pg.keyboard.press('Escape');await pg.wait_for_timeout(100);r['esc fecha config sem pausa']=await vis('#vaPause')
        await pg.evaluate('window.vaPause.open()') if await vis('#vaPause')=='none' else None
        await pg.click('[data-a=restart]',timeout=3000);r['restart 1o clique']=await pg.inner_text('[data-a=restart]')
        async with pg.expect_navigation():
            await pg.click('[data-a=restart]')
        await pg.wait_for_timeout(300);r['save apagado']=not await pg.evaluate("!!localStorage.getItem('projetoR_grunwald_v02')")
        for k,v in r.items():print(k,'=>',v)
        print('errors:',errs[:6]);await b.close()
asyncio.run(main())
