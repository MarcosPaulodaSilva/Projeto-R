import asyncio,sys
from playwright.async_api import async_playwright
src=sys.argv[1]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);ctx=await b.new_context(viewport={'width':960,'height':540});pg=await ctx.new_page()
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file://'+src);r={}
        r['sem save: botao novo?']=await pg.locator('#newBtn').count()
        await pg.click('#startBtn');await pg.wait_for_timeout(200)
        await pg.evaluate("__setHour(21.5)");await pg.evaluate("window.vaSaga.dev('quests')")
        await pg.keyboard.press('Escape');await pg.click('[data-a=save]')
        await pg.reload();await pg.wait_for_timeout(300)
        r['texto continuar']=await pg.inner_text('#startBtn');r['novo existe']=await pg.locator('#newBtn').count()
        await pg.screenshot(path='tt_title.png')
        await pg.click('#startBtn');await pg.wait_for_timeout(300);r['hora ao continuar']=await pg.inner_text('#ctime')
        r['carta persiste']=await pg.evaluate("vaSagaUnread()")
        await pg.reload();await pg.wait_for_timeout(300)
        await pg.click('#newBtn');r['1o clique']=await pg.inner_text('#newBtn')
        async with pg.expect_navigation():await pg.click('#newBtn')
        await pg.wait_for_timeout(300);r['apos novo: botao continuar?']=await pg.inner_text('#startBtn')
        await pg.click('#startBtn');await pg.wait_for_timeout(300);r['hora novo jogo']=await pg.inner_text('#ctime');r['cartas']=await pg.evaluate("vaSagaUnread()")
        for k,v in r.items():print(k,'=>',v)
        print('errors:',errs[:4]);await b.close()
asyncio.run(main())
