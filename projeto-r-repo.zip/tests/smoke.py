import asyncio,sys
from playwright.async_api import async_playwright
src=sys.argv[1]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+src);await pg.click('#startBtn');await pg.wait_for_timeout(300)
        for k in ['KeyD','KeyR','KeyF','KeyG']:
            await pg.keyboard.down(k);await pg.wait_for_timeout(500);await pg.keyboard.up(k)
        await pg.mouse.click(600,300);await pg.keyboard.press('Space');await pg.wait_for_timeout(300)
        await pg.keyboard.press('F2');await pg.wait_for_timeout(300);await pg.screenshot(path='sm_dev.png');await pg.keyboard.press('F2')
        await pg.evaluate("window.__setHour(10)")
        await pg.evaluate("window.projetoR.enterRuins()");await pg.wait_for_timeout(1500);await pg.screenshot(path='sm_ruins.png')
        await pg.evaluate("window.projetoR.leave()");await pg.wait_for_timeout(800)
        await pg.evaluate("window.__setHour(7)");await pg.wait_for_timeout(800);await pg.screenshot(path='sm_dawn.png')
        print('errors:',errs[:6]);await b.close()
asyncio.run(main())
