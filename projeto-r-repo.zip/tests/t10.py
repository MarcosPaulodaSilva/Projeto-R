import asyncio,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type in('error','warning') else None)
        await pg.goto('file://'+sys.argv[1]);await pg.wait_for_timeout(1500)
        await pg.click('#introGate');await pg.wait_for_timeout(800)
        await pg.evaluate('IntroCinematic.finish(true)');await pg.wait_for_timeout(2500)
        await pg.click('#startBtn');await pg.wait_for_timeout(1500)
        r={}
        r['build']=await pg.evaluate("window.PROJETO_R_BUILD")
        r['auditoria inicial']=await pg.evaluate("vaAudit()")
        # 1) tiro de arco faz um inimigo de costas investigar
        info=await pg.evaluate('''()=>{
          const E=vaDbg.enemies.filter(e=>e.state==='IDLE'&&!e.ranged&&!e.elite&&!e.nightThreat);const P=vaDbg.P;
          for(const e of E){for(let a=0;a<6.28;a+=.4){const x=e.x+Math.cos(a)*6.5,y=e.y+Math.sin(a)*6.5;
            if(x>22&&x<31&&y>1&&y<30&&vaAI.los(e.x,e.y,x,y)){window.__t={e,x,y,a};return{x,y,a,ex:e.x,ey:e.y}}}}return null}''')
        r['posicao de teste']=bool(info)
        await pg.evaluate('''()=>{const {e,x,y,a}=window.__t;e.fx=-Math.cos(a);e.fy=-Math.sin(a);e.homeFx=e.fx;e.homeFy=e.fy;vaAI.log.length=0;window.__vaTP(x,y);P=vaDbg.P}''') if False else None
        await pg.evaluate('''()=>{const {e,x,y,a}=window.__t;e.fx=-Math.cos(a);e.fy=-Math.sin(a);e.homeFx=e.fx;e.homeFy=e.fy;vaAI.log.length=0;window.__vaTP(x,y)}''')
        await pg.wait_for_timeout(400)
        r['sem tiro: estado']=await pg.evaluate("window.__t.e.state")
        await pg.mouse.move(300,270);await pg.keyboard.press('KeyQ');await pg.wait_for_timeout(500)
        r['apos tiro: log']=await pg.evaluate("vaAI.log.map(l=>l.why)")
        # 2) log limitado
        await pg.evaluate("for(let i=0;i<500;i++)vaAI.toInvestigate(window.__t.e,[1,1],'spam')")
        r['log limitado (<=200)']=await pg.evaluate("vaAI.log.length<=200")
        # 3) auditoria detecta violacao e nao dispara em estado sao
        await pg.evaluate("vaDbg.P.gold=-5")
        r['detecta ouro negativo']=await pg.evaluate("vaAudit().some(m=>m.includes('ouro'))")
        await pg.evaluate("vaDbg.P.gold=10")
        await pg.evaluate("window.__setHour(21)");await pg.wait_for_timeout(9000)
        r['violacoes apos 9s de noite']=await pg.evaluate("window.__vaViolations")
        for k,v in r.items():print(k,'=>',v)
        print('console:',[e for e in errs if 'auditoria' in e or 'rror' in e][:5]);await b.close()
asyncio.run(main())
