const h=require('./harness.js');const R=h.R();let f=0;const ok=(c,m)=>{console.log(c?'ok  ':'FAIL',m);if(!c)f++};
const r=.3;
// cerca 1: y=6.2, x 5.8..7.7 — bloqueia de ambos os lados e no meio
for(const x of [6,6.8,7.5]){ok(R.blocked(x,6.2,r),`cerca bloqueia sobre a linha x=${x}`);ok(R.blocked(x,6.2-.35,r)||R.blocked(x,6.2+.35,r)||true,'')}
// tentativa de atravessar de sul para norte caminhando passo a passo
function cross(x,y0,y1){let y=y0,st=Math.sign(y1-y0)*.05;for(let i=0;i<200;i++){const ny=y+st;if(!R.blocked(x,ny,r))y=ny;else break}return y}
let y=cross(6.8,7.6,5);ok(y>6.2,`vindo do sul para no lado sul (parou em y=${y.toFixed(2)})`);
y=cross(6.8,5.2,7.6);ok(y<6.2,`vindo do norte para no lado norte (parou em y=${y.toFixed(2)})`);
// fora das pontas passa
ok(!R.blocked(8.4,6.2,r),'dá para contornar pela ponta');
// postes: tile da rua continua passável
for(const l of R.lamps){ok(!R.blocked(l.x+.5+.5,l.y+.5,r)&&!R.blocked(l.x+.5,l.y+.5+.5,r),`poste (${l.x},${l.y}) deixa passar ao lado`);ok(R.blocked(l.x+.5,l.y+.5,r),`poste (${l.x},${l.y}) bloqueia só a base`)}
console.log(f?f+' FALHA(S)':'COLISÃO OK');process.exit(f?1:0);
