import asyncio,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+sys.argv[1]);await pg.wait_for_timeout(1500)
        await pg.click('#introGate');await pg.wait_for_timeout(800)
        await pg.evaluate('IntroCinematic.finish(true)');await pg.wait_for_timeout(2500)
        await pg.click('#startBtn');await pg.wait_for_timeout(1500)
        vis=lambda sel:pg.evaluate(f"getComputedStyle(document.querySelector('{sel}')).display")
        r={}
        await pg.keyboard.press('Escape');await pg.wait_for_timeout(200);r['pausa']=await vis('#vaPause');await pg.keyboard.press('Escape');await pg.wait_for_timeout(200);r['pausa fecha']=await vis('#vaPause')
        await pg.keyboard.press('F3');await pg.wait_for_timeout(250);r['F3']=await vis('#devPanel');await pg.keyboard.press('F3');await pg.wait_for_timeout(150)
        await pg.keyboard.press('KeyC');await pg.wait_for_timeout(200);r['cronica']=await pg.evaluate("document.getElementById('sagaPanel').classList.contains('show')");await pg.keyboard.press('KeyC')
        await pg.mouse.move(700,250);await pg.keyboard.press('KeyQ');await pg.wait_for_timeout(400);r['Q sem erro']=True
        await pg.evaluate("window.__setHour(10)");await pg.evaluate("window.__vaTP(8.5,13.5)");await pg.wait_for_timeout(700);await pg.screenshot(path='r9_day.png')
        await pg.evaluate("window.projetoR.enterRuins()");await pg.wait_for_timeout(1500);await pg.screenshot(path='r9_ruins.png')
        await pg.evaluate("window.projetoR.leave()");await pg.wait_for_timeout(800)
        r['colisao ainda ativa']=await pg.evaluate("window.vaCollide.blocked(6.5,6.2,.3)")
        for k,v in r.items():print(k,'=>',v)
        print('errors:',errs[:5]);await b.close()
asyncio.run(main())
