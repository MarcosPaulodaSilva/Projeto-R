const h=require('./harness.js');const R=h.R();let fails=0;const ok=(c,m)=>{if(!c){fails++;console.log('FAIL',m)}};
R.setRunning(true);R.devAction('comp');
// ciclo completo de 2 dias com time-lapse, ameaças e spawns forçados
const t0=Date.now();let maxEn=0,hurtIn=new Set();
for(let i=0;i<60*60*3;i++){
  if(i%1800===0){R.T.hour=(R.T.hour+3)%24;}
  if(i%900===0&&R.isNight()){R.devAction('spawn:shadow');R.devAction('spawn:bandit')}
  h.step(1);
  maxEn=Math.max(maxEn,R.enemies.length);
  for(const n of R.villagers){if(n.inside&&n._h!==undefined&&n.hp<n._h-1e-6&&!(n.down>0))hurtIn.add(n.id);n._h=n.hp}
  const P=R.P;if(![P.x,P.y,P.hp,P.st,R.T.hour].every(Number.isFinite)){fails++;console.log('FAIL NaN em',i,P.x,P.y,P.hp,P.st,R.T.hour);break}
  if(R.companion.active&&!Number.isFinite(R.companion.hp)){fails++;console.log('FAIL companion hp');break}
}
ok(hurtIn.size===0,'abrigado ferido: '+[...hurtIn]);
ok(maxEn<80,'inimigos ilimitados: '+maxEn);
console.log('max inimigos',maxEn,'ms',Date.now()-t0);
// save/load roundtrip
const d=R.saveData();h.store['projetoR_grunwald_v02']=JSON.stringify(d);
console.log('save bytes',h.store['projetoR_grunwald_v02'].length);
console.log(fails?fails+' FALHA(S)':'STRESS OK');process.exit(fails?1:0);
