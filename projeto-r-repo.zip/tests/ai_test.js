const h=require('./harness.js');const R=h.R();const ai=h.sandbox.vaAI;let fails=0;const ok=(c,m)=>{console.log(c?'ok  ':'FAIL',m);if(!c)fails++};
R.setRunning(true);h.step(5);
const en=R.enemies.filter(e=>e.state==='IDLE'&&!e.ranged&&!e.elite&&!e.nightThreat);
console.log('inimigos melee idle:',en.length, en.map(e=>e.type+'@'+e.x.toFixed(1)+','+e.y.toFixed(1)).join(' '));
const P=R.P;
function clearSpot(e,r){for(let a=0;a<6.28;a+=.4){const x=e.x+Math.cos(a)*r,y=e.y+Math.sin(a)*r;if(x>=22&&x<31&&y>1&&y<30&&h.sandbox.vaAI.los(e.x,e.y,x,y)){const k=Math.floor(y)*R.N+Math.floor(x);if(!R.solid[k])return[x,y,a]}}return null}
const e=en.find(q=>clearSpot(q,6))||en[0];const cs=clearSpot(e,6);console.log('inimigo de teste',e.type,e.x,e.y,'ponto livre',cs&&cs.map(v=>+v.toFixed(1)));
function put(x,y){P.x=x;P.y=y;P.hp=100;P.vx=P.vy=0}
function reset(){e.state='IDLE';e.alert=0;e.lostT=0;e.lastKnown=null;e.x=e.sx??e.x;e.y=e.sy??e.y;e.hp=e.maxhp}
// 1) visão: à frente, com linha de visão, dentro do raio
reset();e.fx=Math.cos(cs[2]);e.fy=Math.sin(cs[2]);put(cs[0],cs[1]);ok(ai.sees(e,P),'vê o jogador à frente com linha de visão');
// 2) fora do cone (atrás), longe de 2.2
reset();e.fx=-Math.cos(cs[2]);e.fy=-Math.sin(cs[2]);put(cs[0],cs[1]);ok(!ai.sees(e,P),'não vê o jogador pelas costas');
// 3) ruído de ataque o faz investigar
const c5=clearSpot(e,5)||cs;reset();e.fx=-Math.cos(c5[2]);e.fy=-Math.sin(c5[2]);e.homeFx=e.fx;e.homeFy=e.fy;put(c5[0],c5[1]);P.atk=.2;h.step(3);ok(h.sandbox.AI_LOG.some(l=>l.ev==='INVESTIGATE'&&l.why==='ruido'),'ouve ataque às costas e INVESTIGA (log de IA)');
// 4) chegando ao local sem achar: SEARCH depois RETURN depois IDLE
P.atk=0;reset();put(10,10);ai.toInvestigate(e,[e.x-2.5,e.y+2.5],'teste');let seen={};for(let i=0;i<60*14;i++){h.step(1);seen[e.state]=1}
ok(seen.SEARCH,'entra em SEARCH ao chegar na última posição');ok(seen.RETURN,'volta (RETURN)');ok(e.state==='IDLE'||e.state==='RETURN','termina em IDLE/RETURN ('+e.state+')');
// 5) parede bloqueia visão
reset();e.fx=-1;e.fy=0;let wall=null;
for(let x=Math.floor(e.x)-2;x>=Math.floor(e.x)-12&&!wall;x--){const k=Math.floor(e.y)*R.N+x;if(R.solid[k]&&R.ground[k]!==2)wall=x}
if(wall!==null){put(wall-3,e.y);ok(!ai.los(e.x,e.y,P.x,P.y),'parede bloqueia linha de visão');ok(!ai.sees(e,P),'não vê através da parede')}else console.log('sem parede no corredor, pulou');
// 6) perseguição perdida vira investigação (não segue por mágica)
reset();e.fx=Math.cos(c5[2]);e.fy=Math.sin(c5[2]);put(c5[0],c5[1]);h.step(30);ok(e.state==='CHASE'||e.state==='ATTACK','persegue quando vê ('+e.state+')');
// 7) riposta
reset();e.state='ATTACK';P.block=true;P.blockT=.05;P.fx=1;P.fy=0;P.x=e.x-1;P.y=e.y;const par=R.hitPlayer(10,e);ok(par===true&&e.riposte>0,'aparada perfeita abre riposta');
const hp0=e.hp;R.damageEnemy(e,10,P.x,P.y,3);ok(hp0-e.hp>=23,'riposta causa ~2.4x de dano ('+(hp0-e.hp).toFixed(1)+')');ok(e.riposte===0,'riposta é consumida');
// 8) invariantes
for(const x of R.enemies)ok(Number.isFinite(x.x)&&Number.isFinite(x.y)&&Number.isFinite(x.hp),'enemy finito');
console.log(fails?fails+' FALHA(S)':'IA OK');process.exit(fails?1:0);
