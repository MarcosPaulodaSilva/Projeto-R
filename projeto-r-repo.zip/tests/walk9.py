import asyncio,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox']);pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+sys.argv[1]);await pg.wait_for_timeout(1500)
        await pg.click('#introGate');await pg.wait_for_timeout(800)
        await pg.evaluate('IntroCinematic.finish(true)');await pg.wait_for_timeout(2500)
        await pg.click('#startBtn');await pg.wait_for_timeout(2000)
        print('hooks:',await pg.evaluate("[typeof window.__vaTP,typeof window.projetoR,window.projetoR&&Object.keys(window.projetoR).slice(0,12)]"))
        P=lambda:pg.evaluate("window.vaCollide&&window.__vaPos?window.__vaPos():null")
        await pg.evaluate("window.__vaTP(6.8,7.5)");await pg.wait_for_timeout(300)
        print('antes',await P())
        # tenta andar para cima (norte no mundo = -y) segurando varias direcoes
        for keys in (['KeyR'],['KeyR','KeyD'],['KeyR','KeyG']):
            await pg.evaluate("window.__vaTP(6.8,7.5)");await pg.wait_for_timeout(200)
            for k in keys:await pg.keyboard.down(k)
            await pg.wait_for_timeout(1800)
            for k in keys:await pg.keyboard.up(k)
            print(keys,'depois',await P())
        await pg.screenshot(path='w9.png');print('errors',errs[:4]);await b.close()
asyncio.run(main())
