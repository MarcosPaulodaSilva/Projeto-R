const h=require('./harness.js');const R=h.R();const{solid,N}=R;
const seen=new Uint8Array(N*N);const q=[[8,13]];seen[13*N+8]=1;let c=0;
while(q.length){const[x,y]=q.pop();c++;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=N||ny>=N)continue;const i=ny*N+nx;if(seen[i]||solid[i])continue;seen[i]=1;q.push([nx,ny])}}
const need=[];for(const n of R.villagers){for(const k of ['work','door','square'])if(n[k])need.push([n.id+'.'+k,n[k][0],n[k][1]])}
need.push(['gate',27,6],['portal-front',26,7],['konrad',R.NPC.x,R.NPC.y]);
const bad=need.filter(p=>!seen[Math.floor(p[2])*N+Math.floor(p[1])]);
console.log('tiles alcançáveis',c,'| inalcançáveis:',bad.map(b=>b[0]).join(',')||'nenhum');
