// Invariantes do Projeto R (0.14). Uso: node invariants.js [arquivo.html]
const h=require('./harness.js');const R=h.R();let fails=0;
const ok=(c,m)=>{if(!c){fails++;console.log('FAIL',m)}};
const fin=(...v)=>v.every(Number.isFinite);
function audit(tag){
  const{P,companion,villagers,enemies,inventory}=R;
  ok(fin(P.x,P.y,P.hp,P.st),`${tag}: player finito`);
  ok(fin(companion.hp),`${tag}: companion hp finito`);
  for(const n of villagers){ok(fin(n.x,n.y,n.hp)&&n.hp>=0,`${tag}: civil ${n.id} hp/pos válidos`)}
  for(const e of enemies){ok(fin(e.x,e.y,e.hp),`${tag}: inimigo ${e.type||e.kind||''} finito`);if(e.state==='DEAD')ok(!(e.atkT>0&&e.hitActive),`${tag}: morto atacando`)}
  for(const k in inventory)ok(inventory[k]>=0&&Number.isInteger(inventory[k]),`${tag}: inventário ${k} >=0`);
  ok(P.gold===undefined||P.gold>=0,`${tag}: ouro >=0`);
}
// 1) dia
R.setRunning(true);h.step(60*20);audit('dia');
// 2) noite: ameaça + civis abrigados nunca feridos
R.T.hour=20.2;R.T.day=1;
const hurtInside=new Set();const orig=R.hitVillager;
let nightSteps=0,sawThreat=false,insideSeen=false;
for(let i=0;i<60*120;i++){h.step(1);nightSteps++;
  if(R.livingNightThreats().length)sawThreat=true;
  for(const n of R.villagers){if(n.inside){insideSeen=true;if(n._lastHp!==undefined&&n.hp<n._lastHp-1e-6&&!(n.down>0))hurtInside.add(n.id)}n._lastHp=n.hp}
  if(i%600===0)audit('noite@'+i);
  R.T.hour=Math.min(R.T.hour,23.5);
}
console.log('ameaça noturna apareceu:',sawThreat,'| civil abrigado visto:',insideSeen);
ok(hurtInside.size===0,'civil abrigado perdeu HP: '+[...hurtInside]);
// 3) amanhecer
R.T.hour=5.9;h.step(60*60*1);audit('amanhecer');
// 4) save robusto
const d=R.saveData();const j=JSON.stringify(d);ok(!/NaN|null,"hp"/.test(j.replace(/"[^"]*":null/g,'')),'save sem NaN');
console.log(fails?`${fails} FALHA(S)`:'TODOS OS INVARIANTES OK');process.exit(fails?1:0);
