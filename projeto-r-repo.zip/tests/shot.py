import sys,asyncio
from playwright.async_api import async_playwright
src=sys.argv[1];out=sys.argv[2];hour=float(sys.argv[3]) if len(sys.argv)>3 else None
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':960,'height':540})
        errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file://'+src);await pg.wait_for_timeout(500)
        await pg.screenshot(path=out.replace('.png','_title.png'))
        await pg.click('#startBtn');await pg.wait_for_timeout(300)
        if hour is not None: await pg.evaluate(f"window.__setHour&&window.__setHour({hour})")
        await pg.wait_for_timeout(1200)
        await pg.screenshot(path=out)
        print('errors:',errs[:5])
        await b.close()
asyncio.run(main())
