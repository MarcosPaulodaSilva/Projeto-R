#!/usr/bin/env bash
# Uso (na pasta do repositório clonado):  bash push.sh "mensagem do commit"
set -e
git add -A
git commit -m "${1:-Atualiza Projeto R}" || echo "nada novo para commitar"
git push
