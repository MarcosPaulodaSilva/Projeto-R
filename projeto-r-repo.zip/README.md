# Projeto R — Vadronia (HTML5 / Canvas 2D)

Action RPG + roguelike isométrico. Beta: reino de Vadronia (Grünwald, Ruínas de Pedra-Muda).

- **Linha oficial atual:** `index.html` = `versions/projeto-r-v0_14_10-vadronia.html` (0.14.10). Abra o arquivo no navegador.
- **Estado e próximos passos:** `PROJECT_STATE.md` (ler primeiro ao continuar).
- **Canon e regras:** `CONTEXTO_MESTRE_DO_JOGO.md` e `MASTER_DE_MECANICAS.md`.
- **Controles:** RDFG mover · mouse mirar/atacar · Espaço esquivar · Direito/Shift defender/aparar · Q arco · T interagir · E tônico · I/J/K/C/M painéis · Esc pausa · F3 DevTools.
- **tests/**: Playwright (Python) e Node. Ex.: `python3 tests/reg9.py index.html`, `python3 tests/t10.py index.html`.
- **legacy-modules/**: módulos e `build.py` da linha 0.14.1–0.14.6 desta sessão (visual, Crônica, IA, personagens). A 0.14.10 já incorpora o visual, a Crônica e a IA; `va_chars.js` (sprites mais definidos) ainda NÃO foi portado para a 0.14.10.
