# ================================================================
# PROJETO R — CONTEXTO MESTRE DO JOGO
# HTML5 / JAVASCRIPT / CANVAS 2D
# ================================================================

Você está trabalhando no PROJETO R.

Antes de alterar código, leia este documento inteiro como CONTEXTO
CANÔNICO do jogo.

Este texto explica O QUE É O JOGO.

As instruções técnicas, mecânicas e de implementação serão fornecidas
separadamente em outro Master Prompt.


================================================================
1. IDENTIDADE
================================================================

Projeto R é um:

ACTION RPG
+
ROGUELIKE
+
RPG DE EXPLORAÇÃO
+
SIMULAÇÃO LEVE DE MUNDO

em perspectiva 2D isométrica.

A implementação atual é:

HTML5
JavaScript
Canvas 2D.

O jogo mistura:

- exploração;
- combate;
- progressão;
- equipamentos;
- companions;
- NPCs;
- cidades e vilarejos vivos;
- relações;
- quests;
- dungeons;
- bosses;
- ciclo dia/noite;
- perigos ambientais;
- política/nobreza;
- exploração de ruínas antigas.

A intenção NÃO é criar um simulador gigantesco.

O objetivo é criar a sensação de um mundo vivo através da interação
entre sistemas bem construídos.


================================================================
2. FILOSOFIA DO MUNDO
================================================================

O mundo NÃO existe apenas quando o protagonista aparece.

NPCs possuem:

- trabalho;
- casa;
- horários;
- relações;
- responsabilidades;
- perigos;
- atividades;
- acontecimentos próprios.

O jogador entra em um mundo que aparentemente já funcionava antes dele.

O protagonista NÃO é:

- o escolhido;
- predestinado;
- centro sobrenatural do universo.

Sua importância deve ser conquistada através de suas ações.


================================================================
3. PROGRESSÃO NARRATIVA GERAL
================================================================

A progressão conceitual do protagonista é:

aventureiro desconhecido
→ explorador
→ feitos locais
→ reconhecimento
→ Guilda
→ feitos maiores
→ reconhecimento regional
→ reino
→ corte
→ Grandes Casas
→ família real
→ possível importância política.

O jogador começa pequeno.

O mundo não deve tratá-lo imediatamente como alguém especial.


================================================================
4. MUNDO COMPLETO
================================================================

O universo completo possui três reinos:

VADRONIA
MIGRIARD
VITEHRIA.

Porém:

A BETA ATUAL É SOMENTE VADRONIA.

Não produzir conteúdo de Migriard ou Vitehria durante a Beta,
a menos que o usuário peça explicitamente.

Arquitetura compartilhada pode permitir expansão futura,
mas não implementar conteúdo futuro antecipadamente.


================================================================
5. VADRONIA
================================================================

Vadronia é o primeiro reino e o laboratório principal do jogo.

Identidade:

fantasia medieval
+
inspiração germânica
+
natureza bela
+
mistérios muito antigos.

Características:

- grandes montanhas;
- vales;
- florestas de coníferas;
- rios frios;
- pontes;
- estradas antigas;
- fortalezas;
- fazendas;
- ruínas;
- cidades acolhedoras;
- vilarejos;
- cemitérios;
- áreas selvagens.

Vadronia NÃO é um reino permanentemente sombrio.

Existe contraste.

CIVILIZAÇÃO:

quente
acolhedora
humana
colorida
funcional.

NATUREZA PROFUNDA:

antiga
misteriosa
silenciosa
ocasionalmente macabra.

Durante o dia, Vadronia pode ser bonita e convidativa.

Quanto mais distante da civilização,
mais perceptíveis podem ficar os vestígios antigos.


================================================================
6. ASSENTAMENTOS DA BETA
================================================================

Existem quatro assentamentos principais na Beta de Vadronia.

CAPITAL:
Vadronia.

CIDADE GRANDE:
Eisenbruck.

VILAREJOS:
Grünwald.
Nebelheim.

Fazendas, fortalezas, casas isoladas, ruínas, postos de estrada,
acampamentos e outros POIs NÃO são novas cidades principais.


================================================================
7. GRÜNWALD
================================================================

Grünwald é atualmente o principal vertical slice mecânico do projeto.

Ele serve para validar:

- player;
- combate;
- NPCs;
- rotinas;
- casas;
- comércio;
- companions;
- perigo;
- dia/noite;
- quests;
- relações;
- progressão;
- dungeon;
- save;
- integração sistêmica.

Grünwald deve parecer um vilarejo que funciona independentemente
do jogador.

Moradores trabalham, conversam, procuram abrigo, reagem ao clima,
perigo e acontecimentos.

O projeto atual já possui uma implementação considerável dessa área.

NÃO recriar Grünwald do zero sem motivo.


================================================================
8. EISENBRUCK
================================================================

Eisenbruck é a grande cidade secundária de Vadronia.

Deve possuir identidade urbana própria,
mas continuar claramente pertencendo a Vadronia.

Não precisa ser gigantesca fisicamente.

Escala pode ser comunicada através de:

- skyline;
- densidade;
- fachadas;
- áreas inacessíveis;
- NPCs;
- sons;
- arquitetura;
- ruas sugeridas.


================================================================
9. CAPITAL VADRONIA
================================================================

A capital fica em um vale cercado por montanhas.

Castelo Morigan possui forte presença visual.

Áreas conceituais:

- castelo;
- áreas nobres;
- comércio;
- mercado;
- Guilda;
- residências;
- áreas exteriores mais modestas.

A cidade é antiga e orgânica.

Não criar urbanismo perfeitamente geométrico.


================================================================
10. INTERIORES
================================================================

Nem toda casa é explorável.

Categorias:

SCENERY
FUNCTIONAL
SPECIAL.

FUNCTIONAL:

- lojas;
- ferreiro;
- alquimista;
- curandeiro;
- taverna;
- estalagem;
- Guilda.

SPECIAL:

- quests;
- personagens importantes;
- narrativa;
- acontecimentos.

A sensação de cidade grande NÃO depende de permitir entrar
em todas as casas.


================================================================
11. CIVILIZAÇÃO ANTIGA
================================================================

Existe uma civilização extremamente antiga,
quase apagada da história.

Ela é um dos grandes mistérios ambientais de Vadronia.

REGRAS CANÔNICAS:

O verdadeiro nome permanece desconhecido.

A linguagem permanece indecifrável.

Símbolos são estranhos.

Arquitetura é extremamente antiga.

Existem relatos contraditórios.

Existem teorias.

NÃO existe tradução perfeita.

NÃO existe sobrevivente explicando tudo.

NÃO existe revelação final solucionando completamente o mistério.

NÃO inventar automaticamente:

nome oficial;
origem definitiva;
responsável;
história completa;
dicionário mágico;
explicação final.

Algumas ruínas podem ser dungeons.

Muitas outras são somente vestígios ambientais.


================================================================
12. CASA MORIGAN
================================================================

Grafia correta:

MORIGAN.

Família real de Vadronia.


HEINRICH MORIGAN

Antigo rei.

Morreu aos 57 anos,
dois anos antes do começo do jogo.

Causa:

maldição/magia misteriosa e incurável.

Origem:
desconhecida.

Responsável:
desconhecido.

Motivo:
desconhecido.

Esse mistério NÃO precisa ser solucionado.


BEATRICE MORIGAN

45 anos.

Viúva de Heinrich.

Atual governante.

Características:

humilde
carismática
inteligente
forte
gentil
madura
mãe presente.

Sofre emocionalmente com a morte de Heinrich.

Isso deve ser tratado de maneira humana.

Não representá-la automaticamente como incapaz.


HENRY MORIGAN

23 anos.

Filho mais velho.

Características:

introvertido
inteligente
orgulhoso
gentil
cavalheiresco.

Participa da disputa de sucessão.

Perfil mais:

tradicional
administrativo.


JULIAN MORIGAN

19 anos.

Segundo filho.

Gêmeo mais velho de Kian.

Características:

corajoso
impulsivo
estressado
temperamento rápido
gentil
atento.

Participa da disputa de sucessão.

Perfil mais:

militar
ativo.


KIAN MORIGAN

19 anos.

Terceiro filho.

Gêmeo de Julian.

Características:

tímido
carinhoso
ansioso
dependente
criativo.

Não disputa ativamente a sucessão.


NICASIA MORIGAN

18 anos desde o começo do jogo.

Aniversário de lore:

7 de novembro.

Características:

resiliente
empática
proativa
organizada
amorosa
responsável
sensível
honesta
observadora
moderadamente ciumenta
ocasionalmente pessimista.


================================================================
13. PROTAGONISTA
================================================================

O protagonista começa com:

18 ANOS.

Qualquer documentação antiga dizendo que protagonista ou Nicasia
começam aos 17 está OBSOLETA.

Não existe envelhecimento automático.


================================================================
14. TEMPO
================================================================

O jogo possui:

HORAS
+
DIAS.

Ciclo:

AMANHECER
→ DIA
→ ENTARDECER
→ NOITE
→ MADRUGADA
→ AMANHECER.

Tempo afeta:

NPCs
lojas
iluminação
perigos
quests
companions
descanso
acontecimentos.

NÃO EXISTEM:

estações anuais;
envelhecimento;
progressão automática de anos;
sistema anual complexo;
aniversário sistêmico.

Centenas de dias de gameplay NÃO envelhecem personagens.


================================================================
15. GRANDES CASAS
================================================================

Existem três Grandes Casas relevantes.


FALKENBERG

Associada a:

militar
defesa
fortalezas.

Valores:

disciplina
coragem
serviço
liderança.

Símbolo:

falcão diante de montanha.

Pode possuir afinidade inicial maior com Julian.


EICHENWALD

Associada a:

agricultura
florestas
abastecimento
comércio.

Valores:

estabilidade
prosperidade
responsabilidade.

Símbolo:

carvalho com raízes.

Pode possuir afinidade inicial maior com Henry.


SILBERHAIN

Associada a:

administração
conhecimento
história
arquivos
estudo de ruínas.

Valores:

prudência
planejamento
conhecimento.

Símbolo:

lua prateada parcialmente coberta por galhos.

É politicamente cautelosa.


Nenhuma Grande Casa é automaticamente boa ou má.


================================================================
16. HERÁLDICA MORIGAN
================================================================

Símbolos:

coroa prateada
montanha
estrela.

Cores:

azul profundo
prata
branco.

Significados:

montanha = permanência.
estrela = orientação.
coroa = dever dinástico.


================================================================
17. SUCESSÃO
================================================================

Vadronia possui tensão sucessória.

Henry e Julian possuem reivindicações.

Henry NÃO é vilão automático.

Julian NÃO é vilão automático.

Kian NÃO precisa disputar.

O mundo político não deve destruir a personalidade dos personagens
apenas para abrir espaço ao protagonista.

As Grandes Casas influenciam a disputa,
mas não simplesmente escolhem qualquer pessoa aleatória como rei.


================================================================
18. POSSÍVEL ROTA FUTURA DO PROTAGONISTA
================================================================

Muito futuramente,
o protagonista pode conquistar legitimidade política.

Uma possível rota de Vadronia envolve Nicasia.

Isso NÃO ocorre simplesmente porque um medidor chegou ao máximo.

Exige potencialmente:

- relação genuína com Nicasia;
- aprovação de Beatrice;
- apoio de uma Grande Casa;
- reconhecimento popular;
- feitos extraordinários;
- legitimidade;
- resolução coerente da sucessão.

A Beta NÃO precisa concluir essa rota.


================================================================
19. RELACIONAMENTOS
================================================================

Relacionamentos são importantes.

Evitar:

clicar
→ elogiar
→ +5
→ repetir
→ romance.

Relações devem responder a:

- conversas;
- decisões;
- comportamento;
- quests;
- feitos;
- promessas;
- acontecimentos;
- reputação;
- memória.

NPCs importantes lembram acontecimentos relevantes.

Não precisam lembrar literalmente cada frase.


================================================================
20. NICASIA COMO EXEMPLO
================================================================

Nicasia deve possuir vida própria.

Ela pode aparecer em diferentes lugares conforme contexto/rotina.

Exemplos conceituais:

jardim
biblioteca
corredores
pátio.

Ela observa ações.

Pode reagir a:

- como jogador trata pessoas;
- feitos;
- escolhas;
- comportamento;
- acontecimentos anteriores.

Ela não existe apenas esperando o jogador iniciar diálogo.


================================================================
21. GUILDA DE VADRONIA
================================================================

Existe uma grande organização:

GUILDA DE VADRONIA.

Funções:

contratos
exploração
informação
trabalhos
companions
reconhecimento.

Pode abrigar grupos menores.

Evitar criar várias guildas redundantes.


================================================================
22. COMPANIONS
================================================================

Player pode possuir até:

3 companions ativos.

Party máxima:

PLAYER + 3.

Companions são autônomos.

O jogador NÃO deve precisar microgerenciar a IA deles.

Player:

recruta
escolhe
equipa
paga quando aplicável.

Companion decide durante gameplay:

seguir
posicionar
escolher alvo
atacar
recuar/reposicionar
usar habilidades.


================================================================
23. COMBATE
================================================================

Combate é Action RPG.

Deve ser:

responsivo
cadenciado
legível
moderadamente estratégico.

Mecânicas centrais:

attack
stamina
dodge
block
parry
ranged
magic
abilities.

Block e Parry usam o mesmo comando.

Segurar:
BLOCK.

Acertar timing:
PARRY.


================================================================
24. STAMINA
================================================================

Stamina impede spam.

Afeta:

ataques
esquiva
bloqueio.

Possui regeneração e atraso de regeneração.

Bloquear ataques custa stamina.

Stamina insuficiente pode causar Guard Break.


================================================================
25. BUILDS
================================================================

Não existem classes rígidas.

Equipamento define grande parte do estilo.

Arquétipos possíveis:

Sword/Shield
Greatsword
Spear
Dagger
Bow
Staff
Grimoire/Wand.

Misturas são permitidas.


================================================================
26. ATRIBUTOS
================================================================

Atributos principais:

VITALITY
STRENGTH
DEXTERITY
INTELLIGENCE
VIGOR.

Na implementação atual eles já possuem efeitos reais.

Conceitualmente:

VIT → sobrevivência/PV.
STR → dano físico.
DEX → eficiência/agilidade/aparo.
INT → magia/efeitos apropriados.
VIG → stamina e defesa relacionada.


================================================================
27. EQUIPAMENTO
================================================================

Slots previstos incluem:

Main
Secondary
Head
Torso
Hands
Legs
Boots
Amulet
Talismans quando necessário.

Equipamentos devem criar possibilidades,
não apenas números maiores.


================================================================
28. RARIDADE
================================================================

Progressão geral:

Common
Uncommon
Rare
Epic/Very Rare
Legendary.

Itens raros podem modificar mecânicas existentes.

Evitar criar sistemas gigantescos exclusivos para cada item.


================================================================
29. LOOT
================================================================

Loot é parte importante do loop.

Loop conceitual:

explorar
→ combater
→ dungeon
→ obter loot
→ avaliar
→ equipar/vender
→ melhorar build
→ explorar novamente.

Drops importantes devem continuar obtíveis.

Evitar RNG cruel desnecessário.


================================================================
30. ECONOMIA
================================================================

Uma moeda principal.

Serviços:

ferreiro
alquimista
curandeiro
mercadores.

Evitar:

crafting gigantesco
mineração
lenhador
agricultura sistêmica
dezenas de materiais.

Dinheiro resolve grande parte da economia.


================================================================
31. DUNGEONS
================================================================

Dungeons possuem entradas físicas no mundo.

Player confirma entrada.

Depois de entrar:

não existe saída voluntária normal.

Final:

BOSS
ou
DEATH.

Cada dungeon possui boss final.


================================================================
32. DUNGEONS PROCEDURAIS
================================================================

Usar:

salas desenhadas/modulares
+
montagem procedural por seed.

Não gerar tudo como corredores aleatórios.

Estrutura:

Entrance
Combat
Traversal
Loot
Rest
Elite
PreBoss
Boss.

Seeds inválidas devem ser rejeitadas.


================================================================
33. DUNGEON DE GRÜNWALD
================================================================

A implementação atual já possui:

CRIPTA DO MARCO PARTIDO.

Ela é parte importante do vertical slice.

Possui:

- geração por seed;
- módulos de salas;
- combates;
- loot;
- sala de descanso;
- boss;
- progressão;
- persistência.

Boss atual:

GUARDIÃO SEM NOME.

Não remover isso ao continuar o projeto.


================================================================
34. MORTE
================================================================

OVERWORLD:

player é resgatado para cidade/curandeiro apropriado.

Perde XP.

Pode perder nível.

Mantém inventário/equipamento.


DUNGEON:

pode perder:

XP
+
quantidade controlada de loot.

Não apagar tudo.

Itens essenciais/quest/únicos importantes devem ser protegidos.


================================================================
35. COMPANION DOWN
================================================================

Em dungeon:

0 HP
→ INCAPACITATED/DOWN.

Existe janela para resgate.

Player pode recuperá-lo.

Consequência de falha deve seguir regras claras.

Morte permanente nunca pode ocorrer por bug de navegação,
loading ou transição.


================================================================
36. NPCs
================================================================

NPCs não são apenas placas de diálogo.

Podem possuir:

- rotina;
- trabalho;
- casa;
- lazer;
- conversas;
- reação ao perigo;
- saúde;
- memória;
- relações;
- função.

Mas não precisam de simulação cara quando estão distantes.


================================================================
37. NPC SIMULATION
================================================================

Conceitualmente:

FULL
REDUCED
DATA.

Próximo:
simulação completa necessária.

Distante:
estado simplificado.

Muito distante:
dados apenas.

Não simular fisicamente o que o jogador não pode observar.


================================================================
38. CASAS COMO REFÚGIO
================================================================

REGRA IMPORTANTE:

CASAS SÃO REFÚGIOS SEGUROS PARA CIVIS.

Durante perigo noturno:

sombras podem perseguir NPCs enquanto eles estão FORA.

Quando um NPC entra corretamente em sua casa/refúgio:

ele deixa de ser alvo.

A ameaça NÃO deve continuar atacando o NPC através da casa.

NPC dentro de casa deve estar protegido.

Essa regra é importante e deve permanecer.


================================================================
39. PERIGO NOTURNO
================================================================

À noite existe uma ameaça sobrenatural sombria.

Uma criatura/espectro/sombra negra extremamente perigosa
pode surgir na escuridão.

Ela torna a noite mecanicamente diferente do dia.

Luz representa segurança.

No começo:
ameaça muito forte.

Mais tarde:
builds fortes podem conseguir enfrentá-la.


================================================================
40. GRÜNWALD À NOITE
================================================================

A implementação atual experimenta incursões durante a noite.

Moradores:

percebem perigo
→ fogem
→ procuram suas casas/refúgios.

Guardas/companions podem proteger moradores.

O amanhecer encerra progressivamente a ameaça.


================================================================
41. KONRAD
================================================================

Konrad é atualmente um personagem central do vertical slice mecânico.

Ele funciona como:

guarda
+
possível companion.

Sua IA deve ser competente.

Ele pode:

- proteger moradores;
- combater ameaças;
- acompanhar player;
- reposicionar;
- retornar às responsabilidades quando apropriado.

Não permitir que ele simplesmente abandone a vila,
atravesse áreas sem motivo ou fique preso em comportamento inválido.


================================================================
42. NPCs ATUAIS DE GRÜNWALD
================================================================

O projeto atual inclui personagens como:

Konrad
Brunna
Elsbeth
Otto
Gerda.

Eles ajudam a testar:

quests
lojas
cura
relações
memória
economia
rotinas
acontecimentos.


================================================================
43. MUNDO REATIVO
================================================================

O valor do Projeto R vem especialmente de sistemas interagindo.

Exemplo:

fica noite
→ moradores mudam rotina
→ ameaça aparece
→ civis fogem
→ casas viram refúgio
→ guardas reagem
→ companion reage
→ combate acontece
→ alguém pode se ferir
→ curandeiro reage depois
→ diálogos mudam
→ relações podem registrar feitos.

Esse tipo de cadeia é desejável.


================================================================
44. QUESTS
================================================================

Quests devem responder ao mundo.

Categorias:

locais
Guilda
exploração
dungeons
personagens
companions
reino
progressão principal.

Evitar excesso de marcadores artificiais.

Acontecimentos prévios devem poder satisfazer objetivos
quando fizer sentido.


================================================================
45. SAVE
================================================================

Save deve preservar estado importante:

player
progressão
inventário
equipamento
quests
relações
companions
tempo
NPCs importantes
flags
economia importante
dungeons concluídas.

Não salvar dados transitórios desnecessários.


================================================================
46. VISUAL
================================================================

Projeto R possui identidade visual de:

pixel art isométrica medieval fantasy.

Porém, nos projetos de TESTE MECÂNICO:

VISUAL É SECUNDÁRIO.

É permitido usar:

formas
cores
labels
hitboxes
sprites simples
animações mínimas.

A versão mecânica existe para descobrir e aperfeiçoar gameplay.

Não gastar trabalho mecânico tentando deixar laboratório bonito.


================================================================
47. REFERÊNCIAS VISUAIS
================================================================

As reference sheets fornecidas anteriormente são:

CONCEPT / VISUAL REFERENCE.

Não são spritesheets runtime perfeitos.

Elas possuem inconsistências de:

escala
proporção
grid
perspectiva
pixel density
animação.

Usar conceitos.

Não copiar erros.


================================================================
48. VERSÃO ATUAL
================================================================

A LINHA OFICIAL ATUAL É:

0.25.x.

A versão-base permanece:

0.25.

Continuações devem utilizar:

0.25.1
0.25.2
0.25.3
0.25.4
...

NÃO avançar automaticamente para:

0.26
0.27
1.0

sem pedido explícito do usuário.

Arquivos experimentais que possuam outro número NÃO mudam
automaticamente a linha oficial.


================================================================
49. PRINCÍPIO DE FUSÃO
================================================================

Existem diferentes experimentos/versões do Projeto RHTML.

Ao combinar projetos:

VERSIONS/0.25 é a base principal.

Se uma mecânica existe tanto na base quanto em outro experimento:

preservar a implementação da base quando ela for superior/mais estável.

Se outro projeto possuir uma mecânica que a base NÃO possui:

ela pode ser integrada.

Se outro projeto possuir uma implementação claramente melhor:

comparar através de teste antes de substituir.

NÃO copiar cegamente.

NÃO duplicar sistemas.


================================================================
50. MECÂNICAS EXPERIMENTAIS JÁ EXPLORADAS
================================================================

Experimentos recentes incluem melhorias como:

- percepção direcional;
- visão;
- ruído;
- investigação;
- busca;
- memória da última posição vista;
- alerta local;
- combate melee respeitando obstáculos;
- controle de quantidade de atacantes simultâneos;
- melhorias de navegação.

Essas ideias devem ser avaliadas pelo benefício real no gameplay.


================================================================
51. FILOSOFIA FINAL DO JOGO
================================================================

Projeto R deve criar a sensação de:

"Eu estou dentro de um mundo que funciona sem mim,
mas minhas ações conseguem mudar partes dele."

Profundidade deve vir principalmente de:

SISTEMAS SIMPLES
+
BOA INTEGRAÇÃO
+
CONSEQUÊNCIAS
+
COMPORTAMENTO COERENTE.

Não de centenas de sistemas isolados.

Este é o contexto canônico do Projeto R.

Use-o para entender o jogo antes de trabalhar no código.