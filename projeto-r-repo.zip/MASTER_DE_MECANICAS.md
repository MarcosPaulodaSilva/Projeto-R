# ================================================================
# PROJETO R — MASTER DE MECÂNICAS
# HTML5 / JAVASCRIPT / CANVAS 2D
# MECÂNICAS, IA, INTEGRAÇÃO, TESTES E REVISÃO
# ================================================================


================================================================
0. FUNÇÃO
================================================================

Você é responsável pela ENGENHARIA DE GAMEPLAY do Projeto RHTML.

O contexto canônico do jogo foi fornecido separadamente.

Seu trabalho agora é:

IMPLEMENTAR
MELHORAR
APROFUNDAR
INTEGRAR
TESTAR
CORRIGIR

as mecânicas do jogo.

PRIORIDADE:

MECÂNICA
>
INTEGRAÇÃO
>
ROBUSTEZ
>
IA
>
TESTABILIDADE
>
BALANCEAMENTO
>
PERFORMANCE
>
VISUAL.

O visual precisa apenas demonstrar corretamente a mecânica.


================================================================
1. NÃO RECOMEÇAR
================================================================

Existem múltiplos projetos/versões/experimentos do Projeto RHTML.

ANTES DE ALTERAR:

1. examine os arquivos disponíveis;
2. examine PROJECT_STATE;
3. execute versões relevantes;
4. identifique sistemas existentes;
5. compare implementações;
6. preserve trabalho funcional.

NÃO recrie o projeto do zero.

NÃO substitua sistema funcional apenas por preferência.


================================================================
2. LINHA OFICIAL
================================================================

Versão-base oficial:

0.25.

Continuações:

0.25.1
0.25.2
0.25.3
...

Nunca avance para 0.26+ sem ordem explícita do usuário.


================================================================
3. FUSÃO DE PROJETOS
================================================================

Ao encontrar múltiplas implementações:

COMPARE.

Se base 0.25 possui sistema melhor:
PRESERVE.

Se outro projeto possui sistema inexistente na 0.25:
INTEGRE quando compatível.

Se outro projeto possui sistema aparentemente superior:
TESTE antes de substituir.

Nunca:

copiar arquivo inteiro cegamente;
duplicar sistema;
regredir funcionalidade estável.


================================================================
4. REGRA DE QUALIDADE
================================================================

Uma mecânica não está pronta apenas porque funciona uma vez.

Ela precisa:

funcionar;
integrar;
ser observável;
ser testável;
resistir a edge cases;
não quebrar outros sistemas.


================================================================
5. CICLO OBRIGATÓRIO
================================================================

Para cada melhoria:

INSPECIONAR
→ IMPLEMENTAR
→ EXECUTAR
→ TESTAR
→ TENTAR QUEBRAR
→ CORRIGIR
→ TESTAR INTEGRAÇÃO
→ REGRESSÃO
→ ATUALIZAR PROJECT_STATE
→ CONTINUAR.


================================================================
6. AUTONOMIA
================================================================

Você possui autonomia técnica.

Não pergunte ao usuário como resolver detalhes de código.

Escolha:

arquitetura
algoritmos
dados
ordem técnica
correções
testes.

Pergunte somente quando existir decisão de DESIGN realmente importante
que mude a visão do jogo.


================================================================
7. PLAYER
================================================================

Manter e aprofundar:

movement
collision
aim
facing
health
stamina
mana quando aplicável
attack
block
parry
dodge
interaction
inventory
equipment
stats
progression
death.


================================================================
8. MOVEMENT
================================================================

Movimento deve ser:

responsivo
previsível
consistente.

Testar:

paredes
cantos
pontes
casas
árvores
rios
entidades
dodge
knockback
transições.

Entidade nunca deve atravessar obstáculo sólido por bug.


================================================================
9. INPUT
================================================================

Separar conceitualmente:

MoveDirection
AimDirection
FacingDirection.

Não acoplar gameplay profundamente a uma tecla.

Manter controles existentes quando já funcionam.

Atualmente o projeto possui controles próprios.

Não alterá-los arbitrariamente.


================================================================
10. COMBAT CORE
================================================================

Player, enemies, companions, NPCs combatentes e bosses devem reutilizar
um Combat Core coerente.

Pipeline:

Attack Intent
→ Attack State
→ Hit Detection
→ Validation
→ Damage Calculation
→ Defense
→ Status/Modifiers
→ Health
→ Reaction
→ Death/Down.


================================================================
11. ATTACK
================================================================

Ataques devem possuir parâmetros configuráveis:

damage
range
startup
active
recovery
staminaCost
knockback
stagger
tags.

Evitar números espalhados.


================================================================
12. ATTACK PHASES
================================================================

Estados:

STARTUP
ACTIVE
RECOVERY.

Hitboxes só devem causar dano quando apropriado.

Debug deve conseguir mostrar fase atual.


================================================================
13. STAMINA
================================================================

Stamina controla:

attack
dodge
block.

Possui:

max
current
cost
regen
regen delay.

Não permitir ações que exigem stamina sem stamina suficiente,
exceto quando regra específica disser o contrário.


================================================================
14. BLOCK
================================================================

Hold:
BLOCK.

Impacto bloqueado consome stamina.

Ataques diferentes podem gerar custos diferentes.

Stamina insuficiente:

GUARD BREAK.


================================================================
15. PARRY
================================================================

Mesmo input do Block.

Timing correto:

PARRY.

Parry deve produzir vantagem real.

A linha atual também possui conceito de:

PERFECT PARRY
→ RIPOSTE WINDOW.

Preservar se estiver funcional.

Riposta deve gerar benefício perceptível sem trivializar combate.


================================================================
16. DODGE
================================================================

Definir claramente:

duration
distance
stamina cost
invulnerability
recovery.

Testar:

dodge contra parede;
dodge durante ataque;
dodge sem stamina;
múltiplos hits.


================================================================
17. RANGED
================================================================

Projéteis devem possuir:

owner
team
position
velocity
damage
lifetime
collision.

Flechas devem respeitar cenário.

Não atravessar paredes/obstáculos indevidamente.


================================================================
18. MAGIC
================================================================

Quando implementada:

usar Combat Core.

Não criar segundo jogo dentro do sistema mágico.

Reutilizar:

damage
projectile
area
status
cooldown
mana.


================================================================
19. STATUS EFFECTS
================================================================

Sistema compartilhado.

Exemplos:

Burn
Poison
Slow
Stun
Bleed
Buff
Debuff.

Definir:

duration
stack rules
source
effect.


================================================================
20. ENEMY AI
================================================================

Usar estados compreensíveis.

Exemplo:

IDLE
PATROL
DETECT
INVESTIGATE
SEARCH
CHASE
POSITION
ATTACK
RECOVER
RETURN
DEAD.

Nem todo inimigo precisa de todos.


================================================================
21. PERCEPÇÃO
================================================================

IA pode utilizar:

vision radius
vision direction
line of sight
hearing/noise
last known position.

Não usar percepção sofisticada apenas por aparência técnica.

Ela deve mudar comportamento de forma perceptível.


================================================================
22. INVESTIGAÇÃO
================================================================

Se inimigo ouvir algo sem enxergar o alvo:

pode investigar posição.

Se chegar e não encontrar:

SEARCH temporário
→ RETURN.

Não adquirir conhecimento mágico da posição do player.


================================================================
23. LAST KNOWN POSITION
================================================================

Quando perder visão:

inimigo pode lembrar última posição conhecida.

Não seguir player através de parede como se ainda pudesse vê-lo.


================================================================
24. LEASH / RETURN
================================================================

Inimigos possuem área/origem.

Depois de perder combate apropriadamente:

RETURN.

Não perseguir eternamente sem regra.

Entretanto inimigos da estrada atualmente podem manter perseguição
até o jogador retornar à zona segura.

Preservar essa regra enquanto ela fizer sentido no slice.


================================================================
25. MELEE NAVIGATION
================================================================

Inimigo melee NÃO pode atravessar obstáculo para atacar.

Precisa:

encontrar aproximação válida
ou
reposicionar.

Não atacar através de parede.


================================================================
26. ATTACK SLOTS
================================================================

Evitar todos os inimigos melee empilhando no player.

Pode existir limite simples de atacantes simultâneos.

Os demais:

reposicionam
esperam oportunidade
cercam parcialmente.

Não transformar em coreografia artificial.


================================================================
27. ENEMY ROLES
================================================================

Priorizar poucos arquétipos bons.

Atualmente/exemplos:

Bandit Melee
Wolf Charger
Bandit Archer
Veteran Elite.

Expandir comportamento antes de expandir quantidade.


================================================================
28. BOSS
================================================================

Boss reutiliza Combat Core.

Guardião Sem Nome deve permanecer como boss da Cripta atual.

Boss pode possuir:

phases
patterns
telegraphs
arena mechanics.

Fase deve alterar comportamento,
não somente HP/dano.


================================================================
29. RUNAS / AREA DENIAL
================================================================

A linha atual possui runas antigas na Cripta.

Elas servem como:

telegraph
→ danger area
→ explosion/effect.

Companions devem conseguir reconhecê-las e reposicionar.

Não permitir dano de chão ser bloqueado/aparado
quando a regra atual definir que não pode.


================================================================
30. NPC CORE
================================================================

NPCs devem compartilhar infraestrutura.

Dados possíveis:

PersistentID
Name
Role
Home
Work
Schedule
Health
Relationship
Flags
CurrentState.

Não criar código totalmente separado para cada cidadão.


================================================================
31. NPC SCHEDULE
================================================================

Estados conceituais:

HOME
WORK
LEISURE
TRAVEL
SLEEP
EMERGENCY.

Perigo interrompe rotina.

Quando perigo acaba:

NPC deve recuperar rotina coerentemente.


================================================================
32. NPC FULL / REDUCED / DATA
================================================================

NPC próximo:
FULL.

NPC relevante mas não imediato:
REDUCED.

NPC distante:
DATA.

Não manter AI, pathfinding e animação completa
para entidade que o jogador não pode observar.


================================================================
33. CIVILIAN HEALTH
================================================================

Moradores possuem PV.

Podem sofrer dano.

No slice atual:

0 HP
→ incapacitado
→ recuperação.

Eles NÃO possuem permadeath atualmente.

Preservar até decisão contrária explícita.


================================================================
34. CIVILIAN DANGER
================================================================

Civil detecta perigo:

→ interrompe rotina
→ procura refúgio
→ foge
→ entra em segurança
→ permanece protegido
→ retorna quando seguro.


================================================================
35. CASAS SEGURAS — REGRA ABSOLUTA
================================================================

CASA/REFÚGIO VÁLIDO = SEGURANÇA PARA CIVIL.

Sombras podem perseguir e atacar NPC enquanto ele está fora.

Assim que NPC entra corretamente no refúgio:

- remover como alvo;
- impedir dano da sombra;
- impedir perseguição através da casa;
- manter NPC protegido.

NÃO permitir novamente o bug de sombras matarem NPCs dentro das casas.


================================================================
36. GUARD AI
================================================================

Guardas devem:

perceber ameaça
proteger área
proteger civis
lutar
reposicionar
retornar ao dever.

Konrad é principal caso de teste.


================================================================
37. KONRAD
================================================================

Konrad deve funcionar bem tanto como:

GUARDA
quanto
COMPANION.

Como guarda:

não abandonar Grünwald sem motivo.

Como companion:

seguir player corretamente.

Não atravessar ponte/andar para longe por bug de navegação.

Não ficar preso em loop.


================================================================
38. COMPANION CORE
================================================================

Estados:

FOLLOW
COMBAT
REPOSITION
RECOVER
DOWN/INCAPACITATED
TRANSITION.

Player não deve precisar consertar a IA manualmente.


================================================================
39. COMPANION TARGETING
================================================================

Companion deve escolher alvo considerando:

distance
danger
role
threat to player
threat to civilians
current target
reachable target.

Evitar target switching frenético.


================================================================
40. COMPANION ROLE
================================================================

Arquétipos futuros:

MELEE
RANGED
MAGIC/SUPPORT.

Mesmo Brain compartilhado.

Dados alteram comportamento.


================================================================
41. COMPANION NAVIGATION
================================================================

Ordem de recuperação:

normal movement
→ local steering
→ repath
→ alternate point
→ safe reposition/teleport.

Teleport é failsafe.

Nunca colocar companion:

dentro de parede;
dentro de hazard;
em posição inválida.


================================================================
42. COMPANION DOWN
================================================================

Na dungeon:

0 HP
→ DOWN.

Player recebe janela de resgate.

Passagem de sala pode ser bloqueada enquanto companion está DOWN
quando necessário para evitar abandono acidental.

Testar:

revive
timeout
player death
boss death
room transition
save/load.


================================================================
43. WORLD TIME
================================================================

Manter:

hour
day
timeScale.

Sem:

aging
years
seasons.

DevTools deve permitir acelerar tempo.


================================================================
44. NIGHT THREAT
================================================================

A ameaça noturna deve:

existir sob regras claras;
atacar alvos válidos;
respeitar luz/refúgio;
interagir com guards/companions;
desaparecer/coibir-se no amanhecer conforme regras.

Não gerar inimigos ilimitadamente.


================================================================
45. INCURSÕES
================================================================

A implementação atual possui progressão de incursões durante a noite.

Manter ritmo gradual.

Evitar uma horda única gigantesca.

Testar:

spawn
targeting
civilians
houses
Konrad
dawn cleanup.


================================================================
46. INTERACTION
================================================================

Sistema compartilhado para:

Talk
Shop
Door
Chest
Loot
DungeonEntrance
Bed
QuestObject
Lever
SpecialObject.

Escolher melhor candidato próximo.


================================================================
47. INVENTORY
================================================================

Suportar:

add
remove
stack
use
equip
unequip
sell
quest protection.

Quantidade nunca negativa.

Item inexistente não pode ser equipado.


================================================================
48. EQUIPMENT
================================================================

Slots:

Main
Secondary
Head
Torso
Hands
Legs
Boots
Amulet
Talismans quando aplicável.

Equipamento deve afetar gameplay real.


================================================================
49. ATRIBUTOS
================================================================

Preservar efeitos reais já implementados.

VIT:
PV.

STR:
dano.

DEX:
eficiência de ataque/esquiva e parry.

INT:
eficiência mágica/consumíveis conforme sistema atual.

VIG:
stamina/regen/block.

Não deixar atributo existir apenas na UI.


================================================================
50. DERIVED STATS
================================================================

Calcular centralmente.

Mudança de:

level
attribute
equipment
status

deve atualizar derivados corretamente.


================================================================
51. LOOT
================================================================

Loot tables devem ser testáveis.

Cripta atual possui loot determinístico por seed.

Preservar proteção contra repetição ruim das peças principais
quando aplicável.


================================================================
52. UNIQUE ITEMS
================================================================

Itens únicos:

não duplicar indevidamente.

Itens de quest:

não vender.

Recompensas de primeira conclusão:

persistir imediatamente quando necessário para evitar exploit.


================================================================
53. ECONOMY
================================================================

Testar:

buy
sell
price
discount
upgrade
unique protection
negative gold
duplication.

Não permitir exploit buy/sell infinito.


================================================================
54. SHOPS
================================================================

Estoque básico pode permanecer.

Rotação futura baseada em dias.

Reabrir menu não deve rerollar estoque.


================================================================
55. QUEST CORE
================================================================

Quest states:

LOCKED
AVAILABLE
ACTIVE
READY
COMPLETED
FAILED quando necessário.

Objectives reutilizáveis:

Kill
Talk
Collect
Visit
Interact
Protect
CompleteDungeon
WorldFlag
RelationshipCondition.


================================================================
56. QUEST EVENTS
================================================================

Quest deve reagir a eventos.

Evitar polling de todas as quests a cada frame.

Acontecimento já realizado deve poder contar quando coerente.


================================================================
57. RELATIONSHIPS
================================================================

Relacionamento:

poucos números
+
memórias importantes
+
flags
+
eventos.

Não transformar em simulador psicológico gigante.


================================================================
58. RELATIONSHIP EVENTS
================================================================

Exemplos:

HelpedVillage
ProtectedCivilian
SavedCompanion
KeptPromise
FailedPromise
ImportantDialogueChoice
CompletedQuest
SupportedHouse.

NPCs diferentes podem interpretar evento diferentemente.


================================================================
59. REPUTATION
================================================================

Reputação só deve existir quando produz consequência.

Pode influenciar:

dialogue
shop
quest
guild
politics
NPC reaction.

Não criar dezenas de barras.


================================================================
60. DUNGEON CORE
================================================================

Entrada:
overworld.

Interior:
instância própria.

Saída normal:
boss/death.

Dungeon atual:

CRIPTA DO MARCO PARTIDO.

Não removê-la.


================================================================
61. PROCEDURAL PIPELINE
================================================================

Seed
→ Logical Layout
→ Room Modules
→ Encounters
→ Validation
→ Play.

Não gerar dungeon tile-by-tile sem necessidade.


================================================================
62. VALIDATION
================================================================

Garantir:

Entrance
Boss
reachable path
required rooms reachable
valid transitions
no impossible state.

Seed inválida:
REJECT.


================================================================
63. DUNGEON ROOMS
================================================================

Categorias:

Entrance
Combat
Loot
Rest
Traversal
Elite
PreBoss
Boss.

Reutilizar módulos inteligentemente.


================================================================
64. DUNGEON TRANSITIONS
================================================================

Ao mudar sala:

limpar estados transitórios apropriados.

Exemplos:

projectiles
temporary particles
old attack state
hazard references
invalid targets.

Não apagar estado persistente necessário.


================================================================
65. DUNGEON REWARDS
================================================================

Diferenciar:

room rewards
loot chest
boss reward
first completion reward.

Evitar duplicação por reload/transição.


================================================================
66. DEATH — OVERWORLD
================================================================

Morte:

rescue
→ valid healer/location
→ XP loss
→ possible level down.

Equipment/inventory preservados.


================================================================
67. DEATH — DUNGEON
================================================================

Morte pode:

perder XP
consumir/perder pequena quantidade de loot conforme regras.

Equipment essencial preservado.

Não punir de forma destrutiva.


================================================================
68. LEVEL DOWN
================================================================

Recalcular corretamente:

level
XP
points
derived stats.

Não corromper equipamento já usado.


================================================================
69. SAVE
================================================================

Salvar apenas estado significativo.

Manual save e autosave separados quando implementados.

Persistir:

player
inventory
equipment
attributes
quests
relationships
world flags
time
NPC important state
companion
dungeon completion
economy important state.


================================================================
70. SAVE ROBUSTNESS
================================================================

Testar:

save/load
reload
missing field
version
dungeon state
companion DOWN
NPC injured
world time
unique reward.

Nunca produzir NaN ou estado impossível silenciosamente.


================================================================
71. DEVTOOLS
================================================================

DevTools são parte essencial do projeto.

Manter/expandir F2 e window.DEV.

DevTools deve acelerar testes,
não virar feature decorativa.


================================================================
72. DEVTOOLS — PLAYER
================================================================

Permitir quando útil:

God Mode
Infinite Stamina
Heal
Damage
Kill
Set Level
Give XP
Give Item
Teleport
Set Attributes.


================================================================
73. DEVTOOLS — WORLD
================================================================

Permitir:

Set Time
Time x1/x5/x20
Weather
Teleport
Night Attack
Dawn
World Flags.


================================================================
74. DEVTOOLS — AI
================================================================

Mostrar:

state
target
last known position
path
vision
hearing
home
stuck state
decision.

Permitir pausar AI.


================================================================
75. DEVTOOLS — DUNGEON
================================================================

Permitir:

Enter
Seed
Generate
Room Jump
Spawn Boss
Kill Boss
Validate
Companion Down
Revive.


================================================================
76. DEVTOOLS — PROBES
================================================================

Criar testes reproduzíveis para mecânicas importantes.

Exemplos atuais:

riposte
hazard
companion avoidance
room clear
boss phase.

Adicionar novos probes quando evitarem regressão real.


================================================================
77. ASSERTIONS
================================================================

Verificar invariantes:

HP finite.
Stamina finite.
Money >= 0.
Inventory >= 0.
Unique IDs unique.
Dead entity cannot attack.
Completed quest not active.
Safe civilian cannot be damaged by night threat.
Dungeon boss reachable.
Companion position valid.


================================================================
78. STRESS TESTS
================================================================

Testar quando relevante:

10
25
50+
entidades.

Medir:

FPS
frame time
AI
pathfinding
projectiles
particles.

Não otimizar somente por teoria.


================================================================
79. PERFORMANCE
================================================================

Priorizar:

não atualizar distante;
não pathfind todo frame;
não fazer polling desnecessário;
não gerar garbage excessivo;
não manter regiões irrelevantes ativas.

Mas NÃO remover mecânica boa sem antes otimizar implementação.


================================================================
80. VISUAL DO LAB
================================================================

Visual é secundário.

Pode usar:

formas geométricas
labels
cores
barras
debug lines
hitboxes.

Tudo relevante deve ser VISÍVEL o suficiente para testar.

Não gastar tempo com animação bonita.


================================================================
81. GAME FEEL
================================================================

Game feel mecânico ainda importa.

Feedback simples pode usar:

flash
small hitstop
small shake
text
sound simples
color change.

Não precisa polish artístico.


================================================================
82. MECÂNICAS NOVAS
================================================================

Você pode criar novas mecânicas quando:

aproveitam sistemas existentes;
geram decisão real;
melhoram comportamento;
melhoram profundidade;
fazem sentido no Projeto R.

Evitar feature creep.


================================================================
83. FILTRO 20/80
================================================================

Antes de sistema grande:

"Qual é a menor implementação que entrega a maior parte
da experiência?"

Faça primeiro.

Teste.

Expanda somente se necessário.


================================================================
84. COMPORTAMENTO EMERGENTE
================================================================

Prioridade altíssima.

Queremos cadeias como:

NPC sai para trabalhar
→ noite chega
→ perigo aparece
→ NPC foge
→ guarda reage
→ companion ajuda
→ NPC entra em casa
→ ameaça perde alvo
→ combate continua
→ amanhece
→ perigo termina
→ curandeira trata feridos
→ NPCs comentam o ocorrido
→ relação/reputação registra ações.

Essas interações valem mais que dezenas de features isoladas.


================================================================
85. TESTE REAL
================================================================

Sempre que ambiente permitir:

EXECUTAR NO NAVEGADOR REAL.

Não confiar apenas em sintaxe.

Testar runtime.

Inspecionar console.

Interagir.

Reproduzir bugs.

Usar DevTools/probes.

A implementação anterior já utiliza Chromium/CDP quando necessário.

Continue usando testes reais quando disponíveis.


================================================================
86. REVISÃO AMPLA
================================================================

Após implementação relevante:

revisar:

mecânica nova;
sistemas relacionados;
integração;
visual funcional;
console;
save;
regressões.

Não entregar imediatamente após primeira execução bem-sucedida.


================================================================
87. NÃO FAZER
================================================================

NÃO:

reiniciar projeto;
reescrever tudo;
duplicar Combat Core;
duplicar NPC Core;
duplicar Quest System;
criar AI diferente para cada personagem;
simular distante desnecessariamente;
focar em arte;
focar em animações;
criar dezenas de frameworks;
expandir Migriard/Vitehria;
avançar versão além de 0.25.x;
remover mecânica canônica silenciosamente.


================================================================
88. PROJECT_STATE
================================================================

Depois de cada ciclo importante,
atualizar PROJECT_STATE de forma curta.

Registrar:

DONE
CURRENT
NEXT
KNOWN BUGS
IMPORTANT DECISIONS.

Não escrever diário gigante.


================================================================
89. CONTINUIDADE
================================================================

Quando receber "continue":

NÃO pergunte o que fazer.

Leia:

Master
PROJECT_STATE
arquivos relevantes.

Escolha a próxima melhoria mecânica de maior valor.

Implemente.

Teste.

Corrija.

Continue.


================================================================
90. PRIORIDADE ATUAL
================================================================

A base já é considerável.

Portanto a prioridade NÃO é reconstruir sistemas básicos.

Priorizar:

profundidade;
integração;
IA;
edge cases;
novas interações úteis;
dungeons;
companions;
NPC behavior;
combat;
progression;
quests;
relationships;
world simulation;
economy;
save robustness;
tests.


================================================================
91. CRITÉRIO DE ESCOLHA
================================================================

Quando existirem várias próximas tarefas,
escolher aquela com maior combinação de:

impacto no gameplay
+
integração
+
risco de bug
+
reutilização futura
+
valor de teste.

Não escolher automaticamente a tarefa visualmente mais chamativa.


================================================================
92. DEFINIÇÃO DE PRONTO
================================================================

Uma melhoria está pronta quando:

funciona;
foi executada;
foi testada;
integra corretamente;
edge cases principais foram avaliados;
não introduziu regressão conhecida;
estado foi registrado.


================================================================
93. OBJETIVO FINAL DESTE PROJETO
================================================================

Este projeto HTML deve se tornar a melhor referência mecânica
possível para Projeto R.

Ele não precisa ser a versão visual final.

Ele deve provar:

COMO O JOGO FUNCIONA.

Queremos poder olhar para uma mecânica deste projeto e dizer:

"Isso está bom o suficiente para servir de base para o jogo final."


================================================================
94. COMANDO FINAL
================================================================

Agora examine TODOS os projetos/arquivos disponíveis dentro do
workspace Projeto RHTML.

Não escolha uma versão apenas pelo número.

COMPARE comportamento.

Use 0.25 como linha-base oficial.

Preserve o melhor da base.

Identifique mecânicas superiores nos experimentos.

Integre apenas o que realmente melhora o projeto.

Não perca sistemas existentes.

Não introduza regressões.

Não priorize acabamento visual.

Priorize mecânicas profundas, utilizáveis, integradas e testadas.

Depois:

EXECUTE
→ TESTE
→ REVISE
→ CORRIJA
→ TESTE NOVAMENTE
→ ATUALIZE PROJECT_STATE
→ CONTINUE.